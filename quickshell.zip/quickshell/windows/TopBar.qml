// macOS 27 (Golden Gate) Liquid Glass unified single-window menu bar.
//
// Full-width transparent/frosted bar with crisp Adwaita Sans typography:
//   Left:  Apple menu, bold Active App name (with window menu), Spaces strip
//   Right: Now Playing glass pill, native macOS 27 overflow button + inline tray,
//          Wi-Fi, Volume (scroll + live HUD), Battery, Spotlight, Control Center,
//          and Date & Time (Calendar + Machine Stats).
import Quickshell
import Quickshell.Wayland
import Quickshell.Services.SystemTray
import QtQuick
import QtQuick.Controls
import "../theme"
import "../state"
import "../services"
import "../components"
import "../modules/Left"
import "../modules/Right"

PanelWindow {
    id: root

    WlrLayershell.namespace: "quickshell"
    WlrLayershell.layer: WlrLayer.Top

    color: "transparent"

    anchors {
        top: true
        left: true
        right: true
    }

    implicitHeight: ShellState.focusMode ? 2 : Theme.barHeight
    exclusiveZone: ShellState.focusMode ? 0 : Theme.barHeight

    Behavior on implicitHeight {
        NumberAnimation { duration: Theme.animDuration; easing.type: Easing.InOutCubic }
    }
    Behavior on exclusiveZone {
        NumberAnimation { duration: Theme.animDuration; easing.type: Easing.InOutCubic }
    }

    property date now: new Date()
    Timer {
        interval: 1000
        running: true
        repeat: true
        onTriggered: root.now = new Date()
    }

    readonly property var trayItems: SystemTray.items.values
    readonly property int maxInlineTray: Math.max(0, SettingsService.trayMaxVisible)
    readonly property bool hasOverflow: trayItems.length > maxInlineTray

    // ── Liquid Glass Bar Surface ────────────────────────────────────────────
    Rectangle {
        id: barSurface
        anchors.fill: parent
        color: Theme.barBg

        Behavior on color { ColorAnimation { duration: Theme.animFast } }

        // Subtle dark top-edge scrim so white menu bar text stays crisp even
        // over bright sky/snow wallpapers while keeping the bar transparent.
        Rectangle {
            anchors.fill: parent
            visible: !Theme.reduceTransparency
            gradient: Gradient {
                GradientStop { position: 0.0; color: Qt.rgba(0, 0, 0, 0.34) }
                GradientStop { position: 1.0; color: Qt.rgba(0, 0, 0, 0.14) }
            }
        }

        // Subtle refractive top-to-bottom sheen
        Rectangle {
            anchors.fill: parent
            visible: !Theme.reduceTransparency && (Theme.showBarBackground || Theme.glassTint > 0.05)
            gradient: Gradient {
                GradientStop { position: 0.0; color: Qt.rgba(1, 1, 1, 0.10 * Math.max(Theme.glassTint, Theme.showBarBackground ? 0.65 : 0)) }
                GradientStop { position: 1.0; color: Qt.rgba(1, 1, 1, 0.01) }
            }
        }

        // Specular bottom hairline when background or tint is enabled
        Rectangle {
            anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
            height: 1
            visible: Theme.showBarBackground || Theme.reduceTransparency || Theme.glassTint > 0.35
            color: Qt.rgba(1, 1, 1, Theme.reduceTransparency ? 0.16 : 0.22)
        }
    }

    // ── Bar Content ─────────────────────────────────────────────────────────
    Item {
        anchors.fill: parent
        opacity: ShellState.focusMode ? 0 : 1
        visible: opacity > 0

        Behavior on opacity { NumberAnimation { duration: Theme.animFast } }

        // ── LEFT CLUSTER: Apple Menu + Active App + Spaces ──────────────────
        Row {
            id: leftCluster
            anchors {
                left: parent.left
                leftMargin: 10
                verticalCenter: parent.verticalCenter
            }
            spacing: 4

            // Arch Linux / System Menu
            BarPill {
                id: appleBtn
                active: ShellState.appleMenuOpen
                hPad: 9
                onActivated: ShellState.toggle("appleMenu")

                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: "\uf303"
                    color: Theme.text
                    font.family: Theme.iconFont
                    font.pixelSize: 15
                    style: Text.Raised
                    styleColor: Qt.rgba(0, 0, 0, 0.55)
                }
            }

            // Bold Active Application Name (opens App / Window menu)
            BarPill {
                id: appBtn
                active: ShellState.appMenuOpen
                hPad: 9
                onActivated: ShellState.toggle("appMenu")

                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: HyprlandService.activeAppName
                    color: Theme.text
                    font.family: Theme.fontFamily
                    font.pixelSize: 13
                    font.weight: Font.DemiBold
                    style: Text.Raised
                    styleColor: Qt.rgba(0, 0, 0, 0.55)
                }
            }

            // Subtle vertical divider
            Rectangle {
                visible: SettingsService.showWorkspacesInBar
                width: 1
                height: 12
                anchors.verticalCenter: parent.verticalCenter
                color: Qt.rgba(1, 1, 1, 0.22)
            }

            // Spaces / Workspaces pill strip
            Item {
                visible: SettingsService.showWorkspacesInBar
                width: visible ? ws.implicitWidth + 8 : 0
                height: 24
                anchors.verticalCenter: parent.verticalCenter

                Workspaces {
                    id: ws
                    screen: root.screen
                    anchors.centerIn: parent
                }
            }
        }

        // ── RIGHT CLUSTER: Media, Overflow+Tray, Status, Spotlight, CC, Clock
        Row {
            id: rightCluster
            anchors {
                right: parent.right
                rightMargin: 10
                verticalCenter: parent.verticalCenter
            }
            spacing: 4

            // Compact Now Playing Liquid Glass Pill
            Rectangle {
                visible: SettingsService.showNowPlayingInBar && MediaService.active
                height: 22
                width: mediaRow.implicitWidth + 18
                radius: 11
                antialiasing: true
                layer.enabled: true
                layer.smooth: true
                layer.samples: 4
                anchors.verticalCenter: parent.verticalCenter
                color: ShellState.mediaOpen ? Qt.rgba(1, 1, 1, 0.24)
                     : mediaHover.hovered ? Qt.rgba(1, 1, 1, 0.18)
                     : Qt.rgba(1, 1, 1, 0.11)
                border.width: 1
                border.color: Qt.rgba(1, 1, 1, ShellState.mediaOpen ? 0.34 : 0.18)

                Behavior on color { ColorAnimation { duration: Theme.animFast } }

                Row {
                    id: mediaRow
                    anchors.centerIn: parent
                    spacing: 6

                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: MediaService.playing ? "\uf001" : "\uf04c"
                        color: MediaService.playing ? Theme.macBlue : Theme.subtext1
                        font.family: Theme.iconFont
                        font.pixelSize: 10
                    }

                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        width: Math.min(implicitWidth, 155)
                        text: MediaService.title || "Playing"
                        color: Theme.text
                        font.family: Theme.fontFamily
                        font.pixelSize: 12
                        font.weight: Font.Medium
                        elide: Text.ElideRight
                        style: Text.Raised
                        styleColor: Qt.rgba(0, 0, 0, 0.55)
                    }
                }

                HoverHandler { id: mediaHover; cursorShape: Qt.PointingHandCursor }
                TapHandler { onTapped: ShellState.toggle("media") }
            }

            // macOS 27 Native Overflow Chevron (« / »)
            BarPill {
                visible: root.hasOverflow
                active: ShellState.overflowOpen
                hPad: 7
                onActivated: ShellState.toggle("overflow")

                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: ShellState.overflowOpen ? "\uf101" : "\uf100"
                    color: Theme.text
                    font.family: Theme.iconFont
                    font.pixelSize: 12
                }
            }

            // Inline System Tray icons
            Row {
                visible: root.trayItems.length > 0 && root.maxInlineTray > 0
                spacing: 2
                anchors.verticalCenter: parent.verticalCenter

                Repeater {
                    model: root.trayItems.slice(0, root.maxInlineTray)

                    delegate: Rectangle {
                        id: trayBtn
                        required property var modelData
                        width: 24
                        height: 22
                        radius: 6
                        anchors.verticalCenter: parent.verticalCenter
                        color: trayMouse.containsMouse ? Qt.rgba(1, 1, 1, 0.18) : "transparent"

                        function showMenu() {
                            if (!modelData.hasMenu) return
                            trayMenu.popup(trayBtn, 0, trayBtn.height + 6)
                        }

                        TrayMenu {
                            id: trayMenu
                            handle: trayBtn.modelData.menu
                        }

                        Image {
                            anchors.centerIn: parent
                            width: 15
                            height: 15
                            source: trayBtn.modelData.icon
                            sourceSize: Qt.size(32, 32)
                            fillMode: Image.PreserveAspectFit
                        }

                        MouseArea {
                            id: trayMouse
                            anchors.fill: parent
                            hoverEnabled: true
                            cursorShape: Qt.PointingHandCursor
                            acceptedButtons: Qt.LeftButton | Qt.MiddleButton | Qt.RightButton
                            onClicked: function(event) {
                                if (event.button === Qt.MiddleButton) trayBtn.modelData.secondaryActivate()
                                else if (trayBtn.modelData.hasMenu) trayBtn.showMenu()
                                else trayBtn.modelData.activate()
                            }
                            onWheel: function(event) {
                                const horizontal = event.angleDelta.y === 0
                                trayBtn.modelData.scroll(horizontal ? event.angleDelta.x : event.angleDelta.y, horizontal)
                                event.accepted = true
                            }
                        }
                    }
                }
            }

            // Wi-Fi / Network Icon
            BarPill {
                active: ShellState.controlCenterOpen && ShellState.ccPage === "network"
                hPad: 7
                onActivated: ShellState.toggle("network")

                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: NetworkService.kind === "ethernet" ? "\uf6ff" : NetworkService.glyph
                    color: NetworkService.connected ? Theme.text : Theme.inactive
                    font.family: Theme.iconFont
                    font.pixelSize: 13
                }
            }

            // Sound / Volume Icon (scroll adjusts volume + triggers live HUD)
            BarPill {
                active: ShellState.controlCenterOpen && ShellState.ccPage === "audio"
                hPad: 7
                onActivated: ShellState.toggle("audio")

                WheelHandler {
                    onWheel: function(e) {
                        var delta = e.angleDelta.y > 0 ? 0.05 : -0.05
                        AudioService.adjustVolume(delta)
                        var nextVal = Math.max(0, Math.min(1, AudioService.volume + delta))
                        ShellState.showOsd(AudioService.glyph, "Volume", nextVal)
                    }
                }

                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: AudioService.glyph
                    color: AudioService.muted ? Theme.inactive : Theme.text
                    font.family: Theme.iconFont
                    font.pixelSize: 13
                }
            }

            // Battery Capsule + Percentage (laptops only)
            BarPill {
                visible: BatteryService.visible
                active: false
                hPad: 7
                onActivated: ShellState.toggle("controlCenter")

                Row {
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 5

                    Text {
                        visible: SettingsService.showBatteryPercent
                        anchors.verticalCenter: parent.verticalCenter
                        text: BatteryService.percent + "%"
                        color: Theme.text
                        font.family: Theme.fontFamily
                        font.pixelSize: 12
                        font.weight: Font.Medium
                        style: Text.Raised
                        styleColor: Qt.rgba(0, 0, 0, 0.55)
                    }

                    Item {
                        width: 24
                        height: 12
                        anchors.verticalCenter: parent.verticalCenter

                        Rectangle {
                            x: 0; y: 0
                            width: 21; height: 12
                            radius: 3.5
                            color: "transparent"
                            border.width: 1.2
                            border.color: Qt.rgba(1, 1, 1, 0.80)

                            Rectangle {
                                x: 2; y: 2
                                width: Math.max(2, (parent.width - 4) * Math.max(0, Math.min(1, BatteryService.percentage)))
                                height: parent.height - 4
                                radius: 1.5
                                color: BatteryService.charging ? Theme.macGreen
                                     : BatteryService.percent <= 15 ? Theme.macRed
                                     : BatteryService.percent <= 25 ? Theme.macOrange
                                     : "#ffffff"
                            }
                        }

                        Rectangle {
                            x: 22; y: 3.5
                            width: 2; height: 5
                            radius: 1
                            color: Qt.rgba(1, 1, 1, 0.70)
                        }
                    }
                }
            }

            // Spotlight Search Icon
            BarPill {
                active: ShellState.spotlightOpen
                hPad: 7
                onActivated: ShellState.toggle("spotlight")

                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: "\uf002"
                    color: Theme.text
                    font.family: Theme.iconFont
                    font.pixelSize: 12
                }
            }

            // Control Center Icon (authentic macOS dual toggles)
            BarPill {
                active: ShellState.controlCenterOpen && ShellState.ccPage === "main"
                hPad: 7
                onActivated: ShellState.toggle("controlCenter")

                ControlCenterIcon {
                    anchors.verticalCenter: parent.verticalCenter
                    color: Theme.text
                }
            }

            // Date & Time (authentic macOS format: "Sun Nov 22  5:29 PM")
            BarPill {
                active: ShellState.calendarOpen
                hPad: 9
                onActivated: ShellState.toggle("calendar")

                Row {
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 7

                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: Qt.formatDateTime(root.now, "ddd MMM d")
                        color: Theme.text
                        font.family: Theme.fontFamily
                        font.pixelSize: 13
                        font.weight: Font.Medium
                        style: Text.Raised
                        styleColor: Qt.rgba(0, 0, 0, 0.55)
                    }

                    Text {
                        anchors.verticalCenter: parent.verticalCenter
                        text: Qt.formatDateTime(root.now, "h:mm AP")
                        color: Theme.text
                        font.family: Theme.fontFamily
                        font.pixelSize: 13
                        font.weight: Font.DemiBold
                        style: Text.Raised
                        styleColor: Qt.rgba(0, 0, 0, 0.55)
                    }
                }
            }
        }
    }
}
