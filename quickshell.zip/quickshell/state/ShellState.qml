// Global UI state for the macOS 27 Liquid Glass menu bar and all popovers.
// Exactly one popover is open at a time (enforced by open/toggle/showPage).
pragma Singleton
import QtQuick

QtObject {
    id: root

    // ── Popovers ────────────────────────────────────────────────────────────
    property bool audioOpen:         false
    property bool bluetoothOpen:     false
    property bool networkOpen:       false
    property bool controlCenterOpen: false
    property bool appleMenuOpen:     false
    property bool appMenuOpen:       false
    property bool spotlightOpen:     false
    property bool calendarOpen:      false
    property bool overflowOpen:      false
    property bool mediaOpen:         false
    property bool islandOpen:        false

    // Control Center active page: "main", "network", "bluetooth", "audio",
    // "appearance", "stats", "editControls".
    property string ccPage: "main"

    // Legacy island state kept for IPC compatibility.
    property string islandWidget:   "stats"
    property bool   islandFromHome: false
    property string settingsTab:    "hyprland"
    property string agentsTab:      "claude"

    // ── Transient bar modes ─────────────────────────────────────────────────
    property bool focusMode: false
    property bool doNotDisturb: false
    property bool audioTriggerHovered: false
    property bool userTriggerHovered:  false

    // ── Liquid Glass OSD HUD (volume / brightness feedback) ─────────────────
    property bool   osdVisible: false
    property string osdIcon:    ""
    property string osdLabel:   ""
    property real   osdValue:   0

    property Timer _osdTimer: Timer {
        interval: 1400
        onTriggered: root.osdVisible = false
    }

    function showOsd(icon, label, value) {
        root.osdIcon = icon
        root.osdLabel = label
        root.osdValue = Math.max(0, Math.min(1, value))
        root.osdVisible = true
        root._osdTimer.restart()
    }

    readonly property var _all: ({
        audio:         "audioOpen",
        bluetooth:     "bluetoothOpen",
        network:       "networkOpen",
        controlCenter: "controlCenterOpen",
        appleMenu:     "appleMenuOpen",
        appMenu:       "appMenuOpen",
        spotlight:     "spotlightOpen",
        calendar:      "calendarOpen",
        overflow:      "overflowOpen",
        media:         "mediaOpen",
        island:        "islandOpen"
    })

    readonly property var _ccPages: ({
        network:      "network",
        bluetooth:    "bluetooth",
        audio:        "audio",
        appearance:   "appearance",
        stats:        "stats",
        editControls: "editControls"
    })

    function showPage(page) {
        if (page === "media") {
            root.toggle("media")
            return
        }
        for (var k in root._all) {
            if (k === "controlCenter") continue
            root[root._all[k]] = page !== "main" && k === page
        }
        root.ccPage = page
        root.controlCenterOpen = true
    }

    function back() {
        root.showPage("main")
    }

    function openWidget(widget, fromHome) {
        if (widget === "stats" || widget === "home") {
            root.showPage("stats")
            return
        }
        if (widget === "appearance") {
            root.showPage("appearance")
            return
        }
        if (widget === "launcher") {
            root.open("spotlight")
            return
        }
    }

    function showPassive(widget) {}
    function hidePassive(widget) {}

    function toggleWidget(widget) {
        if (widget === "launcher") {
            root.toggle("spotlight")
            return
        }
        if (root.controlCenterOpen && root.ccPage === widget)
            root.closeAll()
        else
            root.openWidget(widget, false)
    }

    function islandBack() {
        root.closeAll()
    }

    function anyOpen(exceptSelfDismissing) {
        for (var k in root._all) {
            if (exceptSelfDismissing) continue
            if (root[root._all[k]])
                return true
        }
        return false
    }

    function closeAll(except) {
        for (var k in root._all) {
            if (k === except) continue
            root[root._all[k]] = false
        }
    }

    function toggle(name) {
        var page = root._ccPages[name]
        if (page !== undefined) {
            if (root.controlCenterOpen && root.ccPage === page)
                root.closeAll()
            else
                root.showPage(page)
            return
        }
        if (name === "controlCenter") {
            if (root.controlCenterOpen && root.ccPage === "main")
                root.closeAll()
            else
                root.showPage("main")
            return
        }

        var prop = root._all[name]
        if (prop === undefined) {
            console.warn("ShellState.toggle: unknown popup", name)
            return
        }
        var next = !root[prop]
        root.closeAll(next ? name : undefined)
        root[prop] = next
    }

    function open(name) {
        var page = root._ccPages[name]
        if (page !== undefined || name === "controlCenter") {
            root.showPage(page !== undefined ? page : "main")
            return
        }
        var prop = root._all[name]
        if (prop === undefined) return
        root.closeAll(name)
        root[prop] = true
    }

    function close(name) {
        if (root._ccPages[name] !== undefined || name === "controlCenter") {
            if (root.controlCenterOpen) root.closeAll()
            return
        }
        var prop = root._all[name]
        if (prop !== undefined) root[prop] = false
    }

    function isOpen(name) {
        var prop = root._all[name]
        return prop !== undefined && root[prop]
    }
}
