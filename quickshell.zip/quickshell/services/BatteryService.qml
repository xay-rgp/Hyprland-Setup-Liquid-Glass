// Battery via UPower. Mirrors what waybar's battery module showed.
pragma Singleton
import QtQuick
import Quickshell
import Quickshell.Services.UPower
import "."
import "../theme"

QtObject {
    id: root

    readonly property var device: UPower.displayDevice
    readonly property bool available: !!device && device.isPresent
    readonly property bool onBattery: UPower.onBattery

    readonly property real percentage: device && device.percentage !== undefined
                                       ? device.percentage : 0
    readonly property int percent: Math.round(percentage * 100)

    readonly property bool charging:
        device ? device.state === UPowerDeviceState.Charging ||
                 device.state === UPowerDeviceState.FullyCharged
               : false
    readonly property int chargingWatts:
        device && device.state === UPowerDeviceState.Charging &&
        device.changeRate > 0 ? Math.round(device.changeRate) : 0
    readonly property string chargeRateText:
        chargingWatts > 0 ? chargingWatts + "W" : ""
    readonly property string chargingTimeText: {
        if (!device || device.state !== UPowerDeviceState.Charging ||
            !device.timeToFull || device.timeToFull <= 0) return ""
        var minutes = Math.floor(device.timeToFull / 60)
        var hours = Math.floor(minutes / 60)
        var remainingMinutes = minutes % 60
        return (hours > 0 ? hours + "h " : "") + remainingMinutes + "m left"
    }

    readonly property bool isLaptopBattery: device ? device.isLaptopBattery : false

    // Show the battery only on laptop installs where a laptop battery exists.
    readonly property bool visible: !SettingsService.desktopMode && available && device && device.isLaptopBattery

    readonly property string glyph: {
        if (charging) return "\uf0e7"        // bolt
        if (percent >= 90) return "\uf240"
        if (percent >= 65) return "\uf241"
        if (percent >= 40) return "\uf242"
        if (percent >= 15) return "\uf243"
        return "\uf244"
    }

    readonly property color color: {
        if (charging) return Theme.success
        if (percent <= 10) return Theme.urgent
        if (percent <= 25) return Theme.warning
        return Theme.text
    }

    // Time to empty/full, formatted like waybar's tooltip.
    readonly property string timeText: {
        if (!device) return ""
        var secs = charging ? device.timeToFull : device.timeToEmpty
        if (!secs || secs <= 0) return ""
        var h = Math.floor(secs / 3600)
        var m = Math.floor((secs % 3600) / 60)
        return (h > 0 ? h + "h " : "") + m + "m"
    }
}
