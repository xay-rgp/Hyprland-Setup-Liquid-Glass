// macOS 27 Liquid Glass live HUD pill for Volume / Brightness changes.
// Floats cleanly below the menu bar on the right without stealing focus.
import QtQuick
import Quickshell
import Quickshell.Wayland
import "../theme"
import "../state"
import "../components"

PanelWindow {
    id: root

    property bool active: false

    WlrLayershell.namespace: "quickshell"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: WlrKeyboardFocus.None

    anchors { top: true; left: true; right: true }
    implicitHeight: Theme.barHeight + 68
    color: "transparent"
    exclusionMode: ExclusionMode.Ignore

    // Non-interactive HUD: never steals clicks
    mask: Region {}

    readonly property bool shown: active && ShellState.osdVisible
    property real reveal: shown ? 1 : 0
    Behavior on reveal { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }

    visible: shown || reveal > 0

    LiquidGlass {
        anchors {
            top: parent.top
            topMargin: Theme.barHeight + 8
            right: parent.right
            rightMargin: 16
        }
        width: 240
        height: 48
        glassRadius: 24

        opacity: root.reveal
        scale: 0.94 + 0.06 * root.reveal
        transformOrigin: Item.TopRight

        Row {
            anchors {
                fill: parent
                leftMargin: 14
                rightMargin: 14
            }
            spacing: 10

            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: ShellState.osdIcon
                color: Theme.text
                font.family: Theme.iconFont
                font.pixelSize: 15
            }

            // Glossy progress track
            Rectangle {
                anchors.verticalCenter: parent.verticalCenter
                width: parent.width - 72
                height: 7
                radius: 3.5
                color: Qt.rgba(1, 1, 1, 0.18)

                Rectangle {
                    width: parent.width * ShellState.osdValue
                    height: parent.height
                    radius: 3.5
                    color: "#ffffff"
                    Behavior on width { NumberAnimation { duration: 90; easing.type: Easing.OutCubic } }
                }
            }

            Text {
                anchors.verticalCenter: parent.verticalCenter
                width: 34
                horizontalAlignment: Text.AlignRight
                text: Math.round(ShellState.osdValue * 100) + "%"
                color: Theme.subtext1
                font.family: Theme.fontFamily
                font.pixelSize: Theme.fontSizeSmall
                font.bold: true
            }
        }
    }
}
