// macOS 27 Liquid Glass Control Center main bento layout:
// - Connectivity glass card (Wi-Fi, Bluetooth, Night Shift)
// - Focus / Do Not Disturb + Stats & Settings mini tiles
// - macOS 27 Liquid Glass Appearance card (live Glass Tint slider + Bar BG + Reduce Transparency)
// - Display Brightness & Sound Volume glossy pill sliders
// - Now Playing compact glass card
// - Battery pill + Edit Controls button
import QtQuick
import "../theme"
import "../state"
import "../services"
import "../components"

Item {
    id: root

    implicitWidth: Theme.ccWidth
    implicitHeight: column.implicitHeight + Theme.ccPadding * 2

    Column {
        id: column
        anchors {
            top: parent.top
            left: parent.left
            right: parent.right
            margins: Theme.ccPadding
        }
        spacing: 10

        // ── TOP BENTO ROW: Connectivity (Left) + Focus & Mini Tiles (Right) ─
        Row {
            width: parent.width
            spacing: 10

            readonly property real halfW: (width - spacing) / 2

            // Left: Connectivity Liquid Glass Card (exact height match with right bento stack)
            LiquidGlass {
                cardStyle: true
                width: parent.halfW
                height: Math.max(rightBento.implicitHeight, connCol.implicitHeight + 20)

                Column {
                    id: connCol
                    anchors {
                        verticalCenter: parent.verticalCenter
                        left: parent.left
                        right: parent.right
                        leftMargin: 10
                        rightMargin: 10
                    }
                    spacing: 8

                    ConnRow {
                        glyph: NetworkService.glyph
                        title: NetworkService.kind === "ethernet" ? "Ethernet" : "Wi-Fi"
                        subtitle: {
                            if (NetworkService.kind === "ethernet") return "Connected"
                            if (!NetworkService.wifiEnabled) return "Off"
                            return NetworkService.connected ? NetworkService.ssid : "Not Connected"
                        }
                        active: NetworkService.connected
                        activeColor: Theme.macBlue
                        onToggled: NetworkService.toggleWifi()
                        onOpened: ShellState.showPage("network")
                    }

                    ConnRow {
                        glyph: BluetoothService.glyph
                        title: "Bluetooth"
                        subtitle: {
                            if (!BluetoothService.powered) return "Off"
                            var c = BluetoothService.connected
                            if (c.length === 0) return "On"
                            return c[0].name + (c.length > 1 ? " +" + (c.length - 1) : "")
                        }
                        active: BluetoothService.powered
                        activeColor: Theme.macBlue
                        onToggled: BluetoothService.togglePower()
                        onOpened: ShellState.showPage("bluetooth")
                    }

                    ConnRow {
                        visible: SettingsService.ccShowNightShift
                        glyph: "\uf186"
                        title: "Night Shift"
                        subtitle: NightLightService.on ? "On · Warm" : "Off"
                        active: NightLightService.on
                        activeColor: Theme.macOrange
                        onToggled: NightLightService.toggle()
                        onOpened: NightLightService.toggle()
                    }
                }
            }

            // Right: Focus Tile + Two Compact Utility Tiles
            Column {
                id: rightBento
                width: parent.halfW
                spacing: 10

                // Do Not Disturb / Focus Mode Glass Card
                LiquidGlass {
                    cardStyle: true
                    width: parent.width
                    height: 66

                    Row {
                        anchors {
                            fill: parent
                            leftMargin: 10
                            rightMargin: 10
                        }
                        spacing: 10

                        Rectangle {
                            width: 34; height: 34; radius: 17
                            antialiasing: true
                            anchors.verticalCenter: parent.verticalCenter
                            color: ShellState.doNotDisturb ? Theme.macIndigo : Qt.rgba(1, 1, 1, 0.14)
                            border.width: 1
                            border.color: ShellState.doNotDisturb ? Qt.rgba(1, 1, 1, 0.35) : Qt.rgba(1, 1, 1, 0.18)

                            Behavior on color { ColorAnimation { duration: Theme.animFast } }

                            CenteredIcon {
                                anchors.centerIn: parent
                                text: "\uf186"
                                color: "#ffffff"
                                size: 14
                            }
                        }

                        Column {
                            anchors.verticalCenter: parent.verticalCenter
                            width: parent.width - 46
                            spacing: 1

                            Text {
                                width: parent.width
                                text: "Focus"
                                color: Theme.text
                                font.family: Theme.fontFamily
                                font.pixelSize: Theme.fontSize
                                font.bold: true
                            }
                            Text {
                                width: parent.width
                                text: ShellState.doNotDisturb ? "Do Not Disturb" : "Off"
                                color: Theme.subtext0
                                font.family: Theme.fontFamily
                                font.pixelSize: Theme.fontSizeSmall
                                elide: Text.ElideRight
                            }
                        }
                    }

                    HoverHandler { cursorShape: Qt.PointingHandCursor }
                    TapHandler { onTapped: ShellState.doNotDisturb = !ShellState.doNotDisturb }
                }

                // Bottom-right pair: Machine Stats + Appearance Settings
                Row {
                    width: parent.width
                    spacing: 10
                    readonly property real miniW: (width - spacing) / 2

                    MiniGlassTile {
                        width: parent.miniW
                        height: 64
                        glyph: "\uf201"
                        label: "Stats"
                        onClicked: ShellState.showPage("stats")
                    }

                    MiniGlassTile {
                        width: parent.miniW
                        height: 64
                        glyph: "\uf013"
                        label: "Settings"
                        onClicked: ShellState.showPage("appearance")
                    }
                }
            }
        }

        // ── macOS 27 SIGNATURE: Liquid Glass Appearance Card ────────────────
        LiquidGlass {
            visible: SettingsService.ccShowGlassControls
            cardStyle: true
            width: parent.width
            height: glassCol.implicitHeight + 20

            Column {
                id: glassCol
                anchors {
                    top: parent.top
                    left: parent.left
                    right: parent.right
                    margins: 10
                }
                spacing: 8

                Row {
                    width: parent.width
                    Text {
                        text: "Liquid Glass"
                        color: Theme.text
                        font.family: Theme.fontFamily
                        font.pixelSize: Theme.fontSizeSmall
                        font.bold: true
                    }
                    Item { width: parent.width - 150; height: 1 }
                    Text {
                        width: 68
                        horizontalAlignment: Text.AlignRight
                        text: Theme.reduceTransparency ? "Opaque"
                            : Math.round(SettingsService.glassTint * 100) + "% Tint"
                        color: Theme.subtext0
                        font.family: Theme.fontFamily
                        font.pixelSize: Theme.fontSizeSmall
                    }
                }

                // macOS 27 Glass Appearance Slider (Clear <-> Tinted)
                PillSlider {
                    width: parent.width
                    height: 26
                    glyph: "\uf043"
                    value: SettingsService.glassTint
                    fillColor: "#ffffff"
                    onMoved: function(v) {
                        SettingsService.glassTint = v
                        SettingsService.save()
                    }
                    onGlyphClicked: {
                        SettingsService.glassTint = SettingsService.glassTint < 0.5 ? 0.75 : 0.15
                        SettingsService.save()
                    }
                }

                // Quick toggles: Show Menu Bar Background & Reduce Transparency
                Row {
                    width: parent.width
                    spacing: 8
                    readonly property real pillW: (width - spacing) / 2

                    GlassTogglePill {
                        width: parent.pillW
                        label: "Bar Background"
                        active: SettingsService.showBarBackground
                        onToggled: {
                            SettingsService.showBarBackground = !SettingsService.showBarBackground
                            SettingsService.save()
                        }
                    }

                    GlassTogglePill {
                        width: parent.pillW
                        label: "Reduce Glass"
                        active: SettingsService.reduceTransparency
                        onToggled: {
                            SettingsService.reduceTransparency = !SettingsService.reduceTransparency
                            SettingsService.save()
                        }
                    }
                }
            }
        }

        // ── DISPLAY BRIGHTNESS CARD ─────────────────────────────────────────
        LiquidGlass {
            visible: BrightnessService.available && SettingsService.ccShowBrightness
            cardStyle: true
            width: parent.width
            height: 62

            Column {
                anchors {
                    fill: parent
                    leftMargin: 12; rightMargin: 12
                    topMargin: 8; bottomMargin: 8
                }
                spacing: 6

                Row {
                    width: parent.width
                    Text {
                        text: "Display"
                        color: Theme.text
                        font.family: Theme.fontFamily
                        font.pixelSize: Theme.fontSizeSmall
                        font.bold: true
                    }
                    Item { width: parent.width - 90; height: 1 }
                    Text {
                        width: 40
                        horizontalAlignment: Text.AlignRight
                        text: BrightnessService.percent + "%"
                        color: Theme.subtext0
                        font.family: Theme.fontFamily
                        font.pixelSize: Theme.fontSizeSmall
                    }
                }

                PillSlider {
                    width: parent.width
                    height: 26
                    glyph: "\uf185"
                    value: BrightnessService.percent / 100.0
                    fillColor: "#ffffff"
                    onMoved: function(v) {
                        BrightnessService.set(Math.max(1, Math.round(v * 100)))
                    }
                }
            }
        }

        // ── SOUND VOLUME CARD ───────────────────────────────────────────────
        LiquidGlass {
            cardStyle: true
            width: parent.width
            height: 62

            Column {
                anchors {
                    fill: parent
                    leftMargin: 12; rightMargin: 12
                    topMargin: 8; bottomMargin: 8
                }
                spacing: 6

                Item {
                    width: parent.width
                    height: 16

                    Text {
                        anchors { left: parent.left; verticalCenter: parent.verticalCenter }
                        text: "Sound"
                        color: Theme.text
                        font.family: Theme.fontFamily
                        font.pixelSize: Theme.fontSizeSmall
                        font.bold: true
                    }

                    Row {
                        anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                        spacing: 6

                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            text: AudioService.muted ? "Muted" : AudioService.volumePercent + "%"
                            color: Theme.subtext0
                            font.family: Theme.fontFamily
                            font.pixelSize: Theme.fontSizeSmall
                        }

                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            text: "\uf054"
                            color: Theme.subtext0
                            font.family: Theme.iconFont
                            font.pixelSize: 10
                        }

                        HoverHandler { cursorShape: Qt.PointingHandCursor }
                        TapHandler { onTapped: ShellState.showPage("audio") }
                    }
                }

                PillSlider {
                    width: parent.width
                    height: 26
                    glyph: AudioService.glyph
                    value: AudioService.volume
                    fillColor: AudioService.muted ? Qt.rgba(1, 1, 1, 0.40) : "#ffffff"
                    onMoved: function(v) { AudioService.setVolume(v) }
                    onGlyphClicked: AudioService.toggleMute()
                }
            }
        }

        // ── NOW PLAYING COMPACT GLASS CARD ──────────────────────────────────
        LiquidGlass {
            visible: SettingsService.ccShowMedia
            cardStyle: true
            width: parent.width
            height: 62

            Row {
                anchors {
                    fill: parent
                    leftMargin: 10
                    rightMargin: 10
                }
                spacing: 10

                // Album cover thumbnail
                Cover {
                    width: 42
                    height: 42
                    radius: 10
                    anchors.verticalCenter: parent.verticalCenter
                    source: MediaService.artUrl
                }

                // Track info
                Column {
                    anchors.verticalCenter: parent.verticalCenter
                    width: parent.width - 144
                    spacing: 2

                    Text {
                        width: parent.width
                        text: MediaService.active ? MediaService.title : "Not Playing"
                        color: Theme.text
                        font.family: Theme.fontFamily
                        font.pixelSize: Theme.fontSize
                        font.bold: true
                        elide: Text.ElideRight
                    }
                    Text {
                        width: parent.width
                        text: MediaService.active ? (MediaService.artist || "Media") : "Start audio to control"
                        color: Theme.subtext0
                        font.family: Theme.fontFamily
                        font.pixelSize: Theme.fontSizeSmall
                        elide: Text.ElideRight
                    }
                }

                // Transport buttons
                Row {
                    anchors.verticalCenter: parent.verticalCenter
                    spacing: 4

                    IconButton {
                        glyph: "\uf048"
                        size: 26
                        glyphSize: 12
                        enabled: MediaService.canPrev
                        opacity: enabled ? 1 : 0.35
                        onActivated: MediaService.previous()
                    }
                    IconButton {
                        glyph: MediaService.playing ? "\uf04c" : "\uf04b"
                        size: 28
                        glyphSize: 13
                        enabled: MediaService.canToggle
                        opacity: enabled ? 1 : 0.35
                        onActivated: MediaService.toggle()
                    }
                    IconButton {
                        glyph: "\uf051"
                        size: 26
                        glyphSize: 12
                        enabled: MediaService.canNext
                        opacity: enabled ? 1 : 0.35
                        onActivated: MediaService.next()
                    }
                }
            }
        }

        // ── BATTERY ROW (Laptops) ───────────────────────────────────────────
        LiquidGlass {
            visible: BatteryService.visible && SettingsService.ccShowBattery
            cardStyle: true
            width: parent.width
            height: 38

            Row {
                anchors {
                    left: parent.left; leftMargin: 12
                    right: parent.right; rightMargin: 12
                    verticalCenter: parent.verticalCenter
                }
                spacing: 8

                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: BatteryService.glyph
                    color: BatteryService.color
                    font.family: Theme.iconFont
                    font.pixelSize: 14
                }

                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: "Battery"
                    color: Theme.text
                    font.family: Theme.fontFamily
                    font.pixelSize: Theme.fontSizeSmall
                    font.bold: true
                }

                Item { width: 1; height: 1 }
            }

            Text {
                anchors { right: parent.right; rightMargin: 12; verticalCenter: parent.verticalCenter }
                text: BatteryService.percent + "%"
                      + (BatteryService.chargeRateText !== "" ? " · " + BatteryService.chargeRateText : "")
                      + (BatteryService.timeText !== "" ? " · " + BatteryService.timeText : "")
                color: BatteryService.color
                font.family: Theme.fontFamily
                font.pixelSize: Theme.fontSizeSmall
            }
        }

        // ── FOOTER: macOS 27 "Edit Controls" button ─────────────────────────
        Rectangle {
            width: parent.width
            height: 30
            radius: 15
            antialiasing: true
            color: editHover.hovered ? Qt.rgba(1, 1, 1, 0.16) : Qt.rgba(1, 1, 1, 0.08)
            border.width: 1
            border.color: Qt.rgba(1, 1, 1, 0.16)

            Behavior on color { ColorAnimation { duration: Theme.animFast } }

            Text {
                anchors.centerIn: parent
                text: "Edit Controls"
                color: Theme.text
                font.family: Theme.fontFamily
                font.pixelSize: Theme.fontSizeSmall
                font.bold: true
            }

            HoverHandler { id: editHover; cursorShape: Qt.PointingHandCursor }
            TapHandler { onTapped: ShellState.showPage("editControls") }
        }
    }

    // ── Helper Components ───────────────────────────────────────────────────
    component ConnRow: Item {
        id: crow
        property string glyph: ""
        property string title: ""
        property string subtitle: ""
        property bool   active: false
        property color  activeColor: Theme.macBlue
        signal toggled()
        signal opened()

        width: parent.width
        height: 36

        Rectangle {
            id: orb
            anchors { left: parent.left; verticalCenter: parent.verticalCenter }
            width: 30; height: 30; radius: 15
            antialiasing: true
            color: crow.active ? crow.activeColor : Qt.rgba(1, 1, 1, 0.14)
            border.width: 1
            border.color: crow.active ? Qt.rgba(1, 1, 1, 0.35) : Qt.rgba(1, 1, 1, 0.16)

            Behavior on color { ColorAnimation { duration: Theme.animFast } }

            CenteredIcon {
                anchors.centerIn: parent
                text: crow.glyph
                color: "#ffffff"
                size: 13
            }

            HoverHandler { cursorShape: Qt.PointingHandCursor }
            TapHandler { onTapped: crow.toggled() }
        }

        Column {
            anchors {
                left: orb.right; leftMargin: 8
                right: chev.left; rightMargin: 4
                verticalCenter: parent.verticalCenter
            }
            spacing: 0

            Text {
                width: parent.width
                text: crow.title
                color: Theme.text
                font.family: Theme.fontFamily
                font.pixelSize: Theme.fontSizeSmall + 1
                font.bold: true
                elide: Text.ElideRight
            }
            Text {
                width: parent.width
                text: crow.subtitle
                color: Theme.subtext0
                font.family: Theme.fontFamily
                font.pixelSize: 10
                elide: Text.ElideRight
            }
        }

        Text {
            id: chev
            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
            text: "\uf054"
            color: Theme.overlay2
            font.family: Theme.iconFont
            font.pixelSize: 9
        }

        MouseArea {
            anchors { left: orb.right; right: parent.right; top: parent.top; bottom: parent.bottom }
            cursorShape: Qt.PointingHandCursor
            onClicked: crow.opened()
        }
    }

    component MiniGlassTile: LiquidGlass {
        id: mgt
        cardStyle: true
        property string glyph: ""
        property string label: ""
        signal clicked()

        Column {
            anchors.centerIn: parent
            spacing: 4

            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                text: mgt.glyph
                color: Theme.text
                font.family: Theme.iconFont
                font.pixelSize: 16
            }
            Text {
                anchors.horizontalCenter: parent.horizontalCenter
                text: mgt.label
                color: Theme.subtext1
                font.family: Theme.fontFamily
                font.pixelSize: Theme.fontSizeSmall
            }
        }

        HoverHandler { cursorShape: Qt.PointingHandCursor }
        TapHandler { onTapped: mgt.clicked() }
    }

    component GlassTogglePill: Rectangle {
        id: gtp
        property string label: ""
        property bool   active: false
        signal toggled()

        height: 26
        radius: 13
        antialiasing: true
        color: active ? Theme.macBlue : (hover.hovered ? Qt.rgba(1, 1, 1, 0.16) : Qt.rgba(1, 1, 1, 0.09))
        border.width: 1
        border.color: active ? Qt.rgba(1, 1, 1, 0.35) : Qt.rgba(1, 1, 1, 0.16)

        Behavior on color { ColorAnimation { duration: Theme.animFast } }

        Text {
            anchors.centerIn: parent
            text: gtp.label
            color: "#ffffff"
            font.family: Theme.fontFamily
            font.pixelSize: Theme.fontSizeSmall
            font.bold: gtp.active
        }

        HoverHandler { id: hover; cursorShape: Qt.PointingHandCursor }
        TapHandler { onTapped: gtp.toggled() }
    }
}
