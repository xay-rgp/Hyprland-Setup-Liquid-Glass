// Floating macOS 27 Liquid Glass Now Playing popover.
import QtQuick
import Quickshell
import Quickshell.Wayland
import "../theme"
import "../state"
import "../widgets"
import "../components"

PanelWindow {
    id: root

    property bool active: false
    property var  barWindow: null
    readonly property bool open: active && ShellState.mediaOpen

    WlrLayershell.namespace: "quickshell"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    anchors { top: true; bottom: true; left: true; right: true }
    color: "transparent"
    exclusionMode: ExclusionMode.Ignore

    property real reveal: open ? 1 : 0
    Behavior on reveal { NumberAnimation { duration: 200; easing.type: Easing.OutCubic } }

    visible: open || reveal > 0

    mask: Region {
        width: root.open ? root.width : 0
        height: root.open ? root.height : 0
    }

    Shortcut {
        sequence: "Escape"
        enabled: root.open
        onActivated: ShellState.closeAll()
    }

    MouseArea {
        anchors.fill: parent
        enabled: root.open
        onPressed: function(mouse) {
            mouse.accepted = !card.contains(mapToItem(card, mouse.x, mouse.y))
        }
        onClicked: ShellState.closeAll()
    }

    LiquidGlass {
        id: card
        anchors {
            top: parent.top
            topMargin: Theme.barHeight + 8
            right: parent.right
            rightMargin: 120
        }
        width: Math.min(media.implicitWidth, root.width - 24)
        height: Math.min(media.implicitHeight, root.height - Theme.barHeight - 36)
        glassRadius: 24

        opacity: root.reveal
        scale: 0.95 + 0.05 * root.reveal
        transformOrigin: Item.TopRight

        Flickable {
            anchors.fill: parent
            contentWidth: width
            contentHeight: media.implicitHeight
            boundsBehavior: Flickable.StopAtBounds
            clip: true

            MediaWidget {
                id: media
                width: parent.width
                height: implicitHeight
                active: root.open
            }
        }
    }
}
