// macOS 27 Native Menu Bar Overflow Container.
// Expands a sleek Liquid Glass pill beneath the menu bar revealing hidden
// SystemTray status items when icons exceed SettingsService.trayMaxVisible.
import QtQuick
import QtQuick.Controls
import Quickshell
import Quickshell.Wayland
import Quickshell.Services.SystemTray
import "../theme"
import "../state"
import "../services"
import "../components"
import "../modules/Right"

PanelWindow {
    id: root

    property bool active: false
    readonly property bool open: active && ShellState.overflowOpen

    WlrLayershell.namespace: "quickshell"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    anchors { top: true; bottom: true; left: true; right: true }
    color: "transparent"
    exclusionMode: ExclusionMode.Ignore

    property real reveal: open ? 1 : 0
    Behavior on reveal { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }

    visible: open || reveal > 0

    mask: Region {
        width: root.open ? root.width : 0
        height: root.open ? root.height : 0
    }

    Shortcut {
        sequence: "Escape"
        enabled: root.open
        onActivated: ShellState.closeAll()
    }

    MouseArea {
        anchors.fill: parent
        enabled: root.open
        onPressed: function(mouse) {
            mouse.accepted = !card.contains(mapToItem(card, mouse.x, mouse.y))
        }
        onClicked: ShellState.closeAll()
    }

    readonly property var hiddenItems: SystemTray.items.values.slice(Math.max(0, SettingsService.trayMaxVisible))

    LiquidGlass {
        id: card
        anchors {
            top: parent.top
            topMargin: Theme.barHeight + 6
            right: parent.right
            rightMargin: 220
        }
        width: Math.max(120, row.implicitWidth + 20)
        height: 44
        glassRadius: 14

        opacity: root.reveal
        scale: 0.95 + 0.05 * root.reveal
        transformOrigin: Item.TopRight

        Row {
            id: row
            anchors.centerIn: parent
            spacing: 6

            Text {
                visible: root.hiddenItems.length === 0
                text: "No overflow icons"
                color: Theme.subtext0
                font.family: Theme.fontFamily
                font.pixelSize: Theme.fontSizeSmall
            }

            Repeater {
                model: root.hiddenItems

                delegate: Rectangle {
                    id: itemBtn
                    required property var modelData
                    width: 30
                    height: 30
                    radius: 8
                    color: mouse.containsMouse ? Qt.rgba(1, 1, 1, 0.18) : "transparent"

                    function showMenu() {
                        if (!modelData.hasMenu) return
                        trayMenu.popup(itemBtn, 0, itemBtn.height + 4)
                    }

                    TrayMenu {
                        id: trayMenu
                        handle: itemBtn.modelData.menu
                    }

                    Image {
                        anchors.centerIn: parent
                        width: 18
                        height: 18
                        source: itemBtn.modelData.icon
                        sourceSize: Qt.size(36, 36)
                        fillMode: Image.PreserveAspectFit
                    }

                    MouseArea {
                        id: mouse
                        anchors.fill: parent
                        hoverEnabled: true
                        cursorShape: Qt.PointingHandCursor
                        acceptedButtons: Qt.LeftButton | Qt.MiddleButton | Qt.RightButton
                        onClicked: function(event) {
                            if (event.button === Qt.MiddleButton) itemBtn.modelData.secondaryActivate()
                            else if (itemBtn.modelData.hasMenu) itemBtn.showMenu()
                            else {
                                itemBtn.modelData.activate()
                                ShellState.closeAll()
                            }
                        }
                    }
                }
            }
        }
    }
}
