// Authentic macOS 27 Liquid Glass Apple Menu (top-left dropdown).
import QtQuick
import Quickshell
import Quickshell.Wayland
import "../theme"
import "../state"
import "../services"
import "../components"

PanelWindow {
    id: root

    property bool active: false
    readonly property bool open: active && ShellState.appleMenuOpen

    WlrLayershell.namespace: "quickshell"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    anchors { top: true; bottom: true; left: true; right: true }
    color: "transparent"
    exclusionMode: ExclusionMode.Ignore

    property real reveal: open ? 1 : 0
    Behavior on reveal { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }

    visible: open || reveal > 0

    mask: Region {
        width: root.open ? root.width : 0
        height: root.open ? root.height : 0
    }

    Shortcut {
        sequence: "Escape"
        enabled: root.open
        onActivated: ShellState.closeAll()
    }

    MouseArea {
        anchors.fill: parent
        enabled: root.open
        onPressed: function(mouse) {
            mouse.accepted = !card.contains(mapToItem(card, mouse.x, mouse.y))
        }
        onClicked: ShellState.closeAll()
    }

    LiquidGlass {
        id: card
        x: 8
        y: Theme.barHeight + 6
        width: 248
        height: menuCol.implicitHeight + 12
        glassRadius: 14

        opacity: root.reveal
        scale: 0.96 + 0.04 * root.reveal
        transformOrigin: Item.TopLeft

        Column {
            id: menuCol
            anchors {
                top: parent.top
                left: parent.left
                right: parent.right
                margins: 6
            }
            spacing: 2

            MenuItem {
                glyph: "\uf129"
                label: "About This Machine"
                onClicked: ShellState.showPage("stats")
            }

            MenuSep {}

            MenuItem {
                glyph: "\uf013"
                label: "System Settings…"
                onClicked: ShellState.showPage("appearance")
            }

            MenuItem {
                glyph: "\uf1de"
                label: "Edit Control Center…"
                onClicked: ShellState.showPage("editControls")
            }

            MenuItem {
                glyph: "\uf021"
                label: "Reload Hyprland"
                onClicked: {
                    ShellState.closeAll()
                    HyprlandService.reloadConfig()
                }
            }

            MenuSep {}

            MenuItem {
                glyph: "\uf023"
                label: "Lock Screen"
                shortcut: "Super+L"
                onClicked: {
                    ShellState.closeAll()
                    PowerService.lock()
                }
            }

            MenuItem {
                glyph: "\uf01e"
                label: "Restart…"
                onClicked: {
                    ShellState.closeAll()
                    PowerService.reboot()
                }
            }

            MenuItem {
                glyph: "\uf011"
                label: "Shut Down…"
                danger: true
                onClicked: {
                    ShellState.closeAll()
                    PowerService.powerOff()
                }
            }

            MenuSep {}

            MenuItem {
                glyph: "\uf2f5"
                label: "Log Out " + (SystemService.user || "User") + "…"
                onClicked: {
                    ShellState.closeAll()
                    PowerService.logout()
                }
            }
        }
    }

    component MenuSep: Rectangle {
        width: parent.width - 12
        anchors.horizontalCenter: parent.horizontalCenter
        height: 1
        color: Theme.divider
    }

    component MenuItem: Rectangle {
        id: mi
        property string glyph: ""
        property string label: ""
        property string shortcut: ""
        property bool   danger: false
        signal clicked()

        width: parent.width
        height: 28
        radius: 8
        color: hover.hovered ? (danger ? Qt.rgba(1, 0.27, 0.23, 0.35) : Theme.macBlue) : "transparent"

        Behavior on color { ColorAnimation { duration: 90 } }

        Row {
            anchors {
                left: parent.left; leftMargin: 10
                right: parent.right; rightMargin: 10
                verticalCenter: parent.verticalCenter
            }
            spacing: 9

            Text {
                width: 14
                horizontalAlignment: Text.AlignHCenter
                anchors.verticalCenter: parent.verticalCenter
                text: mi.glyph
                color: hover.hovered ? "#ffffff" : (mi.danger ? Theme.macRed : Theme.subtext1)
                font.family: Theme.iconFont
                font.pixelSize: 12
            }

            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: mi.label
                color: hover.hovered ? "#ffffff" : (mi.danger ? Theme.macRed : Theme.text)
                font.family: Theme.fontFamily
                font.pixelSize: Theme.fontSize
            }
        }

        Text {
            visible: mi.shortcut !== ""
            anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
            text: mi.shortcut
            color: hover.hovered ? Qt.rgba(1, 1, 1, 0.85) : Theme.subtext0
            font.family: Theme.fontFamily
            font.pixelSize: Theme.fontSizeSmall
        }

        HoverHandler { id: hover; cursorShape: Qt.PointingHandCursor }
        TapHandler { onTapped: mi.clicked() }
    }
}
