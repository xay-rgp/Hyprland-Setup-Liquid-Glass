// macOS 27 Liquid Glass Calendar + Live System Overview popover (top-right).
// Triggered by clicking the Date & Time in the menu bar.
import QtQuick
import Quickshell
import Quickshell.Wayland
import "../theme"
import "../state"
import "../services"
import "../components"

PanelWindow {
    id: root

    property bool active: false
    readonly property bool open: active && ShellState.calendarOpen

    WlrLayershell.namespace: "quickshell"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    anchors { top: true; bottom: true; left: true; right: true }
    color: "transparent"
    exclusionMode: ExclusionMode.Ignore

    property real reveal: open ? 1 : 0
    Behavior on reveal { NumberAnimation { duration: 200; easing.type: Easing.OutCubic } }

    visible: open || reveal > 0

    onOpenChanged: {
        StatsService.watching = open
        if (open) {
            var d = new Date()
            root.viewYear = d.getFullYear()
            root.viewMonth = d.getMonth()
            root.today = d
        }
    }

    mask: Region {
        width: root.open ? root.width : 0
        height: root.open ? root.height : 0
    }

    property date today: new Date()
    property int  viewYear: today.getFullYear()
    property int  viewMonth: today.getMonth()

    readonly property var monthNames: [
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"
    ]

    readonly property var calendarCells: {
        var first = new Date(viewYear, viewMonth, 1)
        var startDay = first.getDay()
        var daysInMonth = new Date(viewYear, viewMonth + 1, 0).getDate()
        var cells = []
        for (var i = 0; i < startDay; i++) cells.push({ day: "", isToday: false })
        for (var d = 1; d <= daysInMonth; d++) {
            var isT = (d === today.getDate() && viewMonth === today.getMonth() && viewYear === today.getFullYear())
            cells.push({ day: String(d), isToday: isT })
        }
        return cells
    }

    Shortcut {
        sequence: "Escape"
        enabled: root.open
        onActivated: ShellState.closeAll()
    }

    MouseArea {
        anchors.fill: parent
        enabled: root.open
        onPressed: function(mouse) {
            mouse.accepted = !card.contains(mapToItem(card, mouse.x, mouse.y))
        }
        onClicked: ShellState.closeAll()
    }

    LiquidGlass {
        id: card
        anchors {
            top: parent.top
            topMargin: Theme.barHeight + 8
            right: parent.right
            rightMargin: 10
        }
        width: 326
        height: col.implicitHeight + 28
        glassRadius: 24

        opacity: root.reveal
        scale: 0.95 + 0.05 * root.reveal
        transformOrigin: Item.TopRight

        Column {
            id: col
            anchors {
                top: parent.top
                left: parent.left
                right: parent.right
                margins: 14
            }
            spacing: 12

            // Large macOS Date Header
            Column {
                width: parent.width
                spacing: 2

                Text {
                    text: Qt.formatDateTime(root.today, "dddd").toUpperCase()
                    color: Theme.macRed
                    font.family: Theme.fontFamily
                    font.pixelSize: 11
                    font.bold: true
                    font.letterSpacing: 1.0
                }

                Text {
                    text: Qt.formatDateTime(root.today, "MMMM d, yyyy")
                    color: Theme.text
                    font.family: Theme.fontFamily
                    font.pixelSize: 20
                    font.bold: true
                }
            }

            // Interactive Monthly Calendar Glass Card
            LiquidGlass {
                cardStyle: true
                width: parent.width
                height: calCol.implicitHeight + 20

                Column {
                    id: calCol
                    anchors { top: parent.top; left: parent.left; right: parent.right; margins: 10 }
                    spacing: 8

                    // Month navigation header
                    Item {
                        width: parent.width
                        height: 22

                        Text {
                            anchors { left: parent.left; verticalCenter: parent.verticalCenter }
                            text: root.monthNames[root.viewMonth] + " " + root.viewYear
                            color: Theme.text
                            font.family: Theme.fontFamily
                            font.pixelSize: Theme.fontSize
                            font.bold: true
                        }

                        Row {
                            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                            spacing: 4

                            NavBtn {
                                glyph: "\uf053"
                                onClicked: {
                                    if (root.viewMonth === 0) { root.viewMonth = 11; root.viewYear -= 1 }
                                    else root.viewMonth -= 1
                                }
                            }
                            NavBtn {
                                glyph: "\uf054"
                                onClicked: {
                                    if (root.viewMonth === 11) { root.viewMonth = 0; root.viewYear += 1 }
                                    else root.viewMonth += 1
                                }
                            }
                        }
                    }

                    // Day-of-week header
                    Grid {
                        width: parent.width
                        columns: 7
                        Repeater {
                            model: ["S", "M", "T", "W", "T", "F", "S"]
                            Text {
                                required property string modelData
                                width: Math.floor(calCol.width / 7)
                                height: 18
                                horizontalAlignment: Text.AlignHCenter
                                verticalAlignment: Text.AlignVCenter
                                text: modelData
                                color: Theme.subtext0
                                font.family: Theme.fontFamily
                                font.pixelSize: 10
                                font.bold: true
                            }
                        }
                    }

                    // Calendar days grid
                    Grid {
                        width: parent.width
                        columns: 7
                        rowSpacing: 2

                        Repeater {
                            model: root.calendarCells
                            Item {
                                required property var modelData
                                width: Math.floor(calCol.width / 7)
                                height: 26

                                Rectangle {
                                    anchors.centerIn: parent
                                    width: 24; height: 24; radius: 12
                                    color: modelData.isToday ? Theme.macRed : "transparent"

                                    Text {
                                        anchors.centerIn: parent
                                        text: modelData.day
                                        color: modelData.isToday ? "#ffffff" : Theme.text
                                        font.family: Theme.fontFamily
                                        font.pixelSize: 11
                                        font.bold: modelData.isToday
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Live System Stats Widget Card
            LiquidGlass {
                cardStyle: true
                width: parent.width
                height: 78

                Column {
                    anchors { fill: parent; margins: 10 }
                    spacing: 6

                    Item {
                        width: parent.width
                        height: 16

                        Text {
                            anchors { left: parent.left; verticalCenter: parent.verticalCenter }
                            text: (SystemService.host || "System") + " · up " + SystemService.uptime
                            color: Theme.subtext0
                            font.family: Theme.fontFamily
                            font.pixelSize: 10
                            font.bold: true
                        }

                        Text {
                            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                            text: "Details \uf054"
                            color: Theme.macBlue
                            font.family: Theme.fontFamily
                            font.pixelSize: 10
                            font.bold: true
                            HoverHandler { cursorShape: Qt.PointingHandCursor }
                            TapHandler { onTapped: ShellState.showPage("stats") }
                        }
                    }

                    Row {
                        width: parent.width
                        spacing: 10
                        readonly property real colW: (width - spacing) / 2

                        StatMini {
                            width: parent.colW
                            label: "CPU"
                            percent: StatsService.cpuPercent !== null ? Math.round(StatsService.cpuPercent) : 0
                            accent: Theme.macBlue
                        }

                        StatMini {
                            width: parent.colW
                            label: "RAM"
                            percent: MemoryService.totalKb > 0 ? Math.round(MemoryService.percent) : 0
                            accent: Theme.macGreen
                        }
                    }
                }
            }
        }
    }

    component NavBtn: Rectangle {
        id: nb
        property string glyph: ""
        signal clicked()
        width: 22; height: 22; radius: 11
        color: hover.hovered ? Qt.rgba(1, 1, 1, 0.18) : "transparent"
        Text {
            anchors.centerIn: parent
            text: nb.glyph
            color: Theme.subtext1
            font.family: Theme.iconFont
            font.pixelSize: 10
        }
        HoverHandler { id: hover; cursorShape: Qt.PointingHandCursor }
        TapHandler { onTapped: nb.clicked() }
    }

    component StatMini: Column {
        property string label: ""
        property int    percent: 0
        property color  accent: Theme.macBlue
        spacing: 4

        Item {
            width: parent.width
            height: 14
            Text {
                anchors.left: parent.left
                text: parent.parent.label
                color: Theme.text
                font.family: Theme.fontFamily
                font.pixelSize: 11
                font.bold: true
            }
            Text {
                anchors.right: parent.right
                text: parent.parent.percent + "%"
                color: Theme.subtext1
                font.family: Theme.fontFamily
                font.pixelSize: 11
            }
        }

        Rectangle {
            width: parent.width
            height: 6
            radius: 3
            color: Qt.rgba(1, 1, 1, 0.14)
            Rectangle {
                width: parent.width * Math.max(0, Math.min(1, parent.parent.percent / 100))
                height: parent.height
                radius: 3
                color: parent.parent.accent
                Behavior on width { NumberAnimation { duration: 300; easing.type: Easing.OutCubic } }
            }
        }
    }
}
