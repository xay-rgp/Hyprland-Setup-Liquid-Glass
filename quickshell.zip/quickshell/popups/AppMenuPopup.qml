// Active application & Hyprland window actions menu (clicked from bold App name).
import QtQuick
import Quickshell
import Quickshell.Wayland
import "../theme"
import "../state"
import "../services"
import "../components"

PanelWindow {
    id: root

    property bool active: false
    readonly property bool open: active && ShellState.appMenuOpen

    WlrLayershell.namespace: "quickshell"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    anchors { top: true; bottom: true; left: true; right: true }
    color: "transparent"
    exclusionMode: ExclusionMode.Ignore

    property real reveal: open ? 1 : 0
    Behavior on reveal { NumberAnimation { duration: 180; easing.type: Easing.OutCubic } }

    visible: open || reveal > 0

    mask: Region {
        width: root.open ? root.width : 0
        height: root.open ? root.height : 0
    }

    Shortcut {
        sequence: "Escape"
        enabled: root.open
        onActivated: ShellState.closeAll()
    }

    MouseArea {
        anchors.fill: parent
        enabled: root.open
        onPressed: function(mouse) {
            mouse.accepted = !card.contains(mapToItem(card, mouse.x, mouse.y))
        }
        onClicked: ShellState.closeAll()
    }

    LiquidGlass {
        id: card
        x: 42
        y: Theme.barHeight + 6
        width: 248
        height: menuCol.implicitHeight + 12
        glassRadius: 14

        opacity: root.reveal
        scale: 0.96 + 0.04 * root.reveal
        transformOrigin: Item.TopLeft

        Column {
            id: menuCol
            anchors {
                top: parent.top
                left: parent.left
                right: parent.right
                margins: 6
            }
            spacing: 2

            // Header showing focused window title
            Item {
                width: parent.width
                height: 36
                visible: HyprlandService.activeWindowTitle !== ""

                Column {
                    anchors { left: parent.left; right: parent.right; leftMargin: 10; rightMargin: 10; verticalCenter: parent.verticalCenter }
                    spacing: 1
                    Text {
                        width: parent.width
                        text: HyprlandService.activeAppName
                        color: Theme.text
                        font.family: Theme.fontFamily
                        font.pixelSize: Theme.fontSize
                        font.bold: true
                        elide: Text.ElideRight
                    }
                    Text {
                        width: parent.width
                        text: HyprlandService.activeWindowTitle
                        color: Theme.subtext0
                        font.family: Theme.fontFamily
                        font.pixelSize: 10
                        elide: Text.ElideRight
                    }
                }
            }

            Rectangle {
                visible: HyprlandService.activeWindowTitle !== ""
                width: parent.width - 12
                anchors.horizontalCenter: parent.horizontalCenter
                height: 1
                color: Theme.divider
            }

            AppAction {
                glyph: "\uf2d2"
                label: "Toggle Floating"
                shortcut: "Super+W"
                onClicked: { ShellState.closeAll(); HyprlandService.toggleFloating() }
            }

            AppAction {
                glyph: "\uf065"
                label: "Toggle Fullscreen"
                shortcut: "Super+F"
                onClicked: { ShellState.closeAll(); HyprlandService.toggleFullscreen() }
            }

            AppAction {
                glyph: "\uf0db"
                label: "Toggle Split Direction"
                shortcut: "Super+B"
                onClicked: { ShellState.closeAll(); HyprlandService.toggleSplit() }
            }

            Rectangle {
                width: parent.width - 12
                anchors.horizontalCenter: parent.horizontalCenter
                height: 1
                color: Theme.divider
            }

            AppAction {
                glyph: "\uf120"
                label: "New Terminal"
                shortcut: "Super+↵"
                onClicked: { ShellState.closeAll(); HyprlandService.launchCommand("kitty") }
            }

            AppAction {
                glyph: "\uf07b"
                label: "Open Files"
                shortcut: "Super+E"
                onClicked: { ShellState.closeAll(); HyprlandService.launchCommand("nautilus") }
            }

            Rectangle {
                width: parent.width - 12
                anchors.horizontalCenter: parent.horizontalCenter
                height: 1
                color: Theme.divider
            }

            AppAction {
                glyph: "\uf00d"
                label: "Quit " + HyprlandService.activeAppName
                shortcut: "Super+Q"
                danger: true
                onClicked: { ShellState.closeAll(); HyprlandService.closeActiveWindow() }
            }
        }
    }

    component AppAction: Rectangle {
        id: act
        property string glyph: ""
        property string label: ""
        property string shortcut: ""
        property bool   danger: false
        signal clicked()

        width: parent.width
        height: 28
        radius: 8
        color: hover.hovered ? (danger ? Qt.rgba(1, 0.27, 0.23, 0.35) : Theme.macBlue) : "transparent"

        Behavior on color { ColorAnimation { duration: 90 } }

        Row {
            anchors { left: parent.left; leftMargin: 10; verticalCenter: parent.verticalCenter }
            spacing: 9

            Text {
                width: 14
                horizontalAlignment: Text.AlignHCenter
                anchors.verticalCenter: parent.verticalCenter
                text: act.glyph
                color: hover.hovered ? "#ffffff" : (act.danger ? Theme.macRed : Theme.subtext1)
                font.family: Theme.iconFont
                font.pixelSize: 12
            }

            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: act.label
                color: hover.hovered ? "#ffffff" : (act.danger ? Theme.macRed : Theme.text)
                font.family: Theme.fontFamily
                font.pixelSize: Theme.fontSize
            }
        }

        Text {
            visible: act.shortcut !== ""
            anchors { right: parent.right; rightMargin: 10; verticalCenter: parent.verticalCenter }
            text: act.shortcut
            color: hover.hovered ? Qt.rgba(1, 1, 1, 0.85) : Theme.subtext0
            font.family: Theme.fontFamily
            font.pixelSize: Theme.fontSizeSmall
        }

        HoverHandler { id: hover; cursorShape: Qt.PointingHandCursor }
        TapHandler { onTapped: act.clicked() }
    }
}
