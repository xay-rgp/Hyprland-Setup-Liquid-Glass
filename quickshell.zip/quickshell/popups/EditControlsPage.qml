// macOS 27 "Edit Controls" page inside Control Center.
// Lets the user toggle Control Center modules, Menu Bar items, and Tray overflow limit live.
import QtQuick
import "../theme"
import "../services"
import "../components"

Item {
    id: root

    implicitWidth: Theme.ccWidth
    implicitHeight: col.implicitHeight + Theme.ccPadding * 2

    Column {
        id: col
        anchors {
            top: parent.top
            left: parent.left
            right: parent.right
            margins: Theme.ccPadding
        }
        spacing: 10

        Text {
            text: "Edit Controls & Menu Bar"
            color: Theme.text
            font.family: Theme.fontFamily
            font.pixelSize: Theme.fontSizeLarge
            font.bold: true
        }

        // Control Center Modules
        LiquidGlass {
            cardStyle: true
            width: parent.width
            height: ccModCol.implicitHeight + 20

            Column {
                id: ccModCol
                anchors { top: parent.top; left: parent.left; right: parent.right; margins: 10 }
                spacing: 8

                SectionTitle { text: "CONTROL CENTER MODULES" }

                ToggleLine {
                    label: "Liquid Glass Controls"
                    checked: SettingsService.ccShowGlassControls
                    onToggled: { SettingsService.ccShowGlassControls = !SettingsService.ccShowGlassControls; SettingsService.save() }
                }
                ToggleLine {
                    label: "Night Shift Tile"
                    checked: SettingsService.ccShowNightShift
                    onToggled: { SettingsService.ccShowNightShift = !SettingsService.ccShowNightShift; SettingsService.save() }
                }
                ToggleLine {
                    visible: !SettingsService.desktopMode
                    label: "Display Brightness Slider"
                    checked: SettingsService.ccShowBrightness
                    onToggled: { SettingsService.ccShowBrightness = !SettingsService.ccShowBrightness; SettingsService.save() }
                }
                ToggleLine {
                    label: "Now Playing Card"
                    checked: SettingsService.ccShowMedia
                    onToggled: { SettingsService.ccShowMedia = !SettingsService.ccShowMedia; SettingsService.save() }
                }
                ToggleLine {
                    visible: !SettingsService.desktopMode
                    label: "Battery Status Row"
                    checked: SettingsService.ccShowBattery
                    onToggled: { SettingsService.ccShowBattery = !SettingsService.ccShowBattery; SettingsService.save() }
                }
            }
        }

        // Menu Bar Items & Overflow
        LiquidGlass {
            cardStyle: true
            width: parent.width
            height: barModCol.implicitHeight + 20

            Column {
                id: barModCol
                anchors { top: parent.top; left: parent.left; right: parent.right; margins: 10 }
                spacing: 8

                SectionTitle { text: "MENU BAR & OVERFLOW" }

                ToggleLine {
                    label: "Spaces / Workspaces Strip"
                    checked: SettingsService.showWorkspacesInBar
                    onToggled: { SettingsService.showWorkspacesInBar = !SettingsService.showWorkspacesInBar; SettingsService.save() }
                }
                ToggleLine {
                    label: "Now Playing Pill"
                    checked: SettingsService.showNowPlayingInBar
                    onToggled: { SettingsService.showNowPlayingInBar = !SettingsService.showNowPlayingInBar; SettingsService.save() }
                }
                ToggleLine {
                    visible: !SettingsService.desktopMode
                    label: "Battery Percentage"
                    checked: SettingsService.showBatteryPercent
                    onToggled: { SettingsService.showBatteryPercent = !SettingsService.showBatteryPercent; SettingsService.save() }
                }

                // Inline tray icon limit before macOS 27 overflow chevron kicks in
                Item {
                    width: parent.width
                    height: 26

                    Text {
                        anchors { left: parent.left; verticalCenter: parent.verticalCenter }
                        text: "Inline Tray Icons"
                        color: Theme.text
                        font.family: Theme.fontFamily
                        font.pixelSize: Theme.fontSizeSmall + 1
                    }

                    Row {
                        anchors { right: parent.right; verticalCenter: parent.verticalCenter }
                        spacing: 6

                        StepBtn {
                            label: "−"
                            onClicked: {
                                SettingsService.trayMaxVisible = Math.max(0, SettingsService.trayMaxVisible - 1)
                                SettingsService.save()
                            }
                        }

                        Text {
                            width: 20
                            horizontalAlignment: Text.AlignHCenter
                            anchors.verticalCenter: parent.verticalCenter
                            text: String(SettingsService.trayMaxVisible)
                            color: Theme.text
                            font.family: Theme.fontFamily
                            font.pixelSize: Theme.fontSize
                            font.bold: true
                        }

                        StepBtn {
                            label: "+"
                            onClicked: {
                                SettingsService.trayMaxVisible = Math.min(12, SettingsService.trayMaxVisible + 1)
                                SettingsService.save()
                            }
                        }
                    }
                }
            }
        }
    }

    component SectionTitle: Text {
        color: Theme.subtext0
        font.family: Theme.fontFamily
        font.pixelSize: 10
        font.bold: true
        font.letterSpacing: 0.7
    }

    component ToggleLine: Item {
        id: tl
        property string label: ""
        property bool checked: false
        signal toggled()

        width: parent.width
        height: 24

        Text {
            anchors { left: parent.left; verticalCenter: parent.verticalCenter }
            text: tl.label
            color: Theme.text
            font.family: Theme.fontFamily
            font.pixelSize: Theme.fontSizeSmall + 1
        }

        // macOS pill switch
        Rectangle {
            anchors { right: parent.right; verticalCenter: parent.verticalCenter }
            width: 38; height: 22; radius: 11
            color: tl.checked ? Theme.macGreen : Qt.rgba(1, 1, 1, 0.20)
            Behavior on color { ColorAnimation { duration: Theme.animFast } }

            Rectangle {
                x: tl.checked ? parent.width - width - 2 : 2
                y: 2
                width: 18; height: 18; radius: 9
                color: "#ffffff"
                Behavior on x { NumberAnimation { duration: Theme.animFast; easing.type: Easing.OutCubic } }
            }

            HoverHandler { cursorShape: Qt.PointingHandCursor }
            TapHandler { onTapped: tl.toggled() }
        }
    }

    component StepBtn: Rectangle {
        id: sb
        property string label: ""
        signal clicked()
        width: 24; height: 24; radius: 12
        color: hover.hovered ? Qt.rgba(1, 1, 1, 0.24) : Qt.rgba(1, 1, 1, 0.12)
        Text {
            anchors.centerIn: parent
            text: sb.label
            color: Theme.text
            font.family: Theme.fontFamily
            font.pixelSize: 13
            font.bold: true
        }
        HoverHandler { id: hover; cursorShape: Qt.PointingHandCursor }
        TapHandler { onTapped: sb.clicked() }
    }
}
