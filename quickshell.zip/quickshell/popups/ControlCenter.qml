// Floating macOS 27 Liquid Glass Control Center.
// Anchored below the top-right of the menu bar with smooth spring-like reveal,
// hosting Main, Network, Bluetooth, Audio, Appearance, Stats, and Edit Controls pages.
import Quickshell
import Quickshell.Wayland
import QtQuick
import "../theme"
import "../state"
import "../services"
import "../components"
import "../widgets"

PanelWindow {
    id: root

    property var  barWindow: null
    property bool active: false

    readonly property bool open: active && ShellState.controlCenterOpen

    WlrLayershell.namespace: "quickshell"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: root.open ? WlrKeyboardFocus.Exclusive
                                           : WlrKeyboardFocus.None

    anchors {
        top: true
        left: true
        right: true
        bottom: true
    }

    color: "transparent"
    exclusionMode: ExclusionMode.Ignore

    property real reveal: open ? 1 : 0
    Behavior on reveal {
        NumberAnimation { duration: Theme.ccMorphDuration; easing.type: Easing.OutCubic }
    }

    visible: open || reveal > 0

    mask: Region {
        width: root.open ? root.width : 0
        height: root.open ? root.height : 0
    }

    readonly property int targetW: {
        if (ShellState.ccPage === "stats") return 620
        if (ShellState.ccPage === "appearance") return Math.max(Theme.ccWidth, appearancePage.implicitWidth)
        return Theme.ccWidth
    }

    readonly property int maxH: Math.max(300, height - Theme.barHeight - 36)

    readonly property int targetH: {
        var h = Theme.ccHeight
        if (ShellState.ccPage === "main") h = mainPage.implicitHeight
        else if (ShellState.ccPage === "editControls") h = editPage.implicitHeight + 36
        else if (ShellState.ccPage === "appearance") h = appearancePage.implicitHeight + 36
        else if (ShellState.ccPage === "stats") h = statsPage.implicitHeight + 36
        return Math.min(h, maxH)
    }

    Shortcut {
        sequence: "Escape"
        enabled: root.open
        onActivated: ShellState.ccPage === "main" ? ShellState.closeAll() : ShellState.back()
    }

    MouseArea {
        id: backdrop
        anchors.fill: parent
        enabled: root.open
        onPressed: function(mouse) {
            mouse.accepted = !body.contains(mapToItem(body, mouse.x, mouse.y))
        }
        onClicked: ShellState.closeAll()
    }

    // ── Floating Liquid Glass Panel ─────────────────────────────────────────
    LiquidGlass {
        id: body
        anchors {
            top: parent.top
            topMargin: Theme.barHeight + 8
            right: parent.right
            rightMargin: 10
        }
        width: root.targetW
        height: root.targetH
        glassRadius: Theme.ccRadius

        opacity: root.reveal
        scale: 0.95 + 0.05 * root.reveal
        transformOrigin: Item.TopRight

        Behavior on width  { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }
        Behavior on height { NumberAnimation { duration: 220; easing.type: Easing.OutCubic } }

        Page {
            name: "main"
            sub: false
            ControlCenterMain {
                id: mainPage
                width: parent.width
            }
        }

        Page {
            name: "editControls"
            sub: true
            EditControlsPage {
                id: editPage
                width: parent.width
            }
        }

        Page {
            name: "network"
            sub: true
            NetworkPopup {
                width: parent.width
                embedded: true
            }
        }

        Page {
            name: "bluetooth"
            sub: true
            BluetoothPopup {
                width: parent.width
                height: root.targetH - 36
                embedded: true
            }
        }

        Page {
            name: "audio"
            sub: true
            AudioPopup {
                width: parent.width
                embedded: true
            }
        }

        Page {
            name: "appearance"
            sub: true
            AppearanceWidget {
                id: appearancePage
                width: parent.width
                height: implicitHeight
                active: root.open && ShellState.ccPage === "appearance"
            }
        }

        Page {
            name: "stats"
            sub: true
            StatsWidget {
                id: statsPage
                width: parent.width
                height: implicitHeight
                active: root.open && ShellState.ccPage === "stats"
            }
        }
    }

    // ── Page container with cross-fade & back header ────────────────────────
    component Page: Item {
        id: pg

        property string name
        property bool   sub: true
        readonly property bool current: ShellState.ccPage === name
        default property alias content: flick.flickableData

        anchors.fill: parent
        opacity: current ? 1 : 0
        visible: opacity > 0
        enabled: current

        BackRow { id: back; visible: pg.sub }

        Flickable {
            id: flick
            anchors {
                top: pg.sub ? back.bottom : parent.top
                left: parent.left
                right: parent.right
                bottom: parent.bottom
            }
            clip: true
            contentWidth: width
            contentHeight: contentItem.children.length > 0
                           ? contentItem.children[0].implicitHeight || contentItem.children[0].height : 0
            boundsBehavior: Flickable.StopAtBounds
        }

        Behavior on opacity { NumberAnimation { duration: Theme.animFast } }
    }

    component BackRow: Item {
        width: parent ? parent.width : 0
        height: 36

        Rectangle {
            anchors { left: parent.left; leftMargin: 12; verticalCenter: parent.verticalCenter }
            width: backRow.implicitWidth + 18
            height: 26
            radius: 13
            color: backHover.hovered ? Qt.rgba(1, 1, 1, 0.16) : Qt.rgba(1, 1, 1, 0.08)

            Behavior on color { ColorAnimation { duration: Theme.animFast } }

            Row {
                id: backRow
                anchors.centerIn: parent
                spacing: 6

                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: "\uf053"
                    color: Theme.text
                    font.family: Theme.fontFamily
                    font.pixelSize: 10
                }
                Text {
                    anchors.verticalCenter: parent.verticalCenter
                    text: "Control Center"
                    color: Theme.text
                    font.family: Theme.fontFamily
                    font.pixelSize: Theme.fontSizeSmall
                    font.bold: true
                }
            }

            HoverHandler { id: backHover; cursorShape: Qt.PointingHandCursor }
            TapHandler { onTapped: ShellState.back() }
        }
    }
}
