// Floating centered macOS 27 Liquid Glass Spotlight launcher.
import QtQuick
import Quickshell
import Quickshell.Wayland
import "../theme"
import "../state"
import "../components"
import "../widgets"

PanelWindow {
    id: root

    property bool active: false
    readonly property bool open: active && ShellState.spotlightOpen

    WlrLayershell.namespace: "quickshell"
    WlrLayershell.layer: WlrLayer.Overlay
    WlrLayershell.keyboardFocus: open ? WlrKeyboardFocus.Exclusive : WlrKeyboardFocus.None

    anchors { top: true; bottom: true; left: true; right: true }
    color: "transparent"
    exclusionMode: ExclusionMode.Ignore

    property real reveal: open ? 1 : 0
    Behavior on reveal { NumberAnimation { duration: 200; easing.type: Easing.OutCubic } }

    visible: open || reveal > 0

    mask: Region {
        width: root.open ? root.width : 0
        height: root.open ? root.height : 0
    }

    Shortcut {
        sequence: "Escape"
        enabled: root.open
        onActivated: ShellState.closeAll()
    }

    MouseArea {
        anchors.fill: parent
        enabled: root.open
        onPressed: function(mouse) {
            mouse.accepted = !card.contains(mapToItem(card, mouse.x, mouse.y))
        }
        onClicked: ShellState.closeAll()
    }

    LiquidGlass {
        id: card
        anchors.horizontalCenter: parent.horizontalCenter
        y: Math.round(parent.height * 0.16)
        width: Theme.launcherWidth
        height: Theme.launcherMaxHeight
        glassRadius: 22

        opacity: root.reveal
        scale: 0.96 + 0.04 * root.reveal
        transformOrigin: Item.Top

        LauncherWidget {
            anchors.fill: parent
            active: root.open
        }
    }
}
