// Instantiates all macOS 27 Liquid Glass popovers for one monitor.
// Popovers only activate on the currently focused monitor.
import QtQuick
import Quickshell
import "../services"

Item {
    id: root

    property var barWindow: null
    property var screen: null

    readonly property bool active: HyprlandService.isFocused(root.screen)

    ControlCenter {
        screen: root.screen
        barWindow: root.barWindow
        active: root.active
    }

    MediaPopup {
        screen: root.screen
        barWindow: root.barWindow
        active: root.active
    }

    AppleMenuPopup {
        screen: root.screen
        active: root.active
    }

    AppMenuPopup {
        screen: root.screen
        active: root.active
    }

    SpotlightPopup {
        screen: root.screen
        active: root.active
    }

    CalendarStatsPopup {
        screen: root.screen
        active: root.active
    }

    OverflowPopup {
        screen: root.screen
        active: root.active
    }

    OsdHud {
        screen: root.screen
        active: root.active
    }
}
