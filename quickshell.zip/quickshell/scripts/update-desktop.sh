#!/usr/bin/env bash
# Update the Liquid Glass desktop in a terminal, independently of Quickshell.
# Preserves the saved device profile (laptop vs desktop) so desktop installs
# never re-enable brightness or battery features during updates.
set -Eeuo pipefail
state_root="${XDG_STATE_HOME:-$HOME/.local/state}/quickshell"
state_dir="$state_root/updates"
profile_file="$state_root/device-profile"
mkdir -p -- "$state_dir"

if [[ "${1:-}" == --launch ]]; then
    # The installer replaces ~/.config/quickshell, including this script.
    # Execute a private snapshot so the update survives that replacement.
    runner=$(mktemp "$state_dir/runner-XXXXXXXX.sh")
    cp -- "${BASH_SOURCE[0]}" "$runner"
    exec kitty --hold --title 'Update desktop' bash "$runner" --run
fi
[[ "${1:-}" == --run ]] || { echo 'Usage: update-desktop.sh --launch'; exit 2; }
(( EUID != 0 )) || { echo 'Run this as your regular user, not root.'; exit 1; }
exec 9>"$state_dir/update.lock"
flock -n 9 || { echo 'A desktop update is already running.'; exit 1; }
run_dir=$(mktemp -d "$state_dir/$(date +%Y%m%d-%H%M%S)-XXXXXXXX")
exec > >(tee -a "$run_dir/update.log") 2>&1
trap 'code=$?; printf "\nUpdate stopped (exit %s). Log and any backups: %s\n" "$code" "$run_dir"; exit "$code"' ERR

repo="$HOME/Hyprland-Setup-Liquid-Glass"
url='https://github.com/xay-rgp/Hyprland-Setup-Liquid-Glass.git'
printf 'Updating Liquid Glass desktop from %s\n\n' "$url"
if [[ ! -e "$repo" ]]; then
    git clone --branch main --single-branch "$url" "$repo"
fi
[[ -d "$repo/.git" ]] || { echo "Not a Git checkout: $repo"; exit 1; }
remote=$(git -C "$repo" remote get-url origin)
case "$remote" in
    "$url"|https://github.com/xay-rgp/Hyprland-Setup-Liquid-Glass|git@github.com:xay-rgp/Hyprland-Setup-Liquid-Glass.git) ;;
    *) echo "Unexpected origin: $remote. No installer was run."; exit 1 ;;
esac
[[ "$(git -C "$repo" branch --show-current)" == main ]] || {
    echo 'The checkout must be on main. No branches or local changes were discarded.'; exit 1;
}
echo 'Fetching the latest main branch; local changes are retained unless they conflict.'
git -C "$repo" fetch origin main
git -C "$repo" merge --ff-only FETCH_HEAD
[[ -f "$repo/setup-hyprland.sh" ]] || { echo 'setup-hyprland.sh is missing.'; exit 1; }
bash -n "$repo/setup-hyprland.sh"
git -C "$repo" rev-parse HEAD > "$run_dir/revision.txt"
git -C "$repo" status --short > "$run_dir/local-changes.txt"

# Preserve saved device profile (laptop vs desktop) across updates.
device_profile=""
if [[ -f "$profile_file" ]]; then
    device_profile="$(tr -d '[:space:]' < "$profile_file")"
fi
if [[ "$device_profile" != "laptop" && "$device_profile" != "desktop" ]]; then
    if compgen -G "/sys/class/power_supply/BAT*" >/dev/null 2>&1; then
        device_profile="laptop"
    else
        device_profile="desktop"
    fi
    printf '%s\n' "$device_profile" > "$profile_file"
fi
printf 'Device profile: %s (preserved from %s)\n' "$device_profile" "$profile_file"

# The installer deletes Hyprland and Quickshell directories before copying.
echo 'Backing up desktop configuration before installation...'
mkdir -p "$run_dir/config"
for name in hypr quickshell wofi kitty fastfetch fish gtk-4.0 btop; do
    if [[ -e "$HOME/.config/$name" || -L "$HOME/.config/$name" ]]; then
        cp -a -- "$HOME/.config/$name" "$run_dir/config/$name"
    fi
done
printf '\nBackup: %s/config\n' "$run_dir"
printf 'Running setup-hyprland.sh --profile %s (system packages and desktop files).\n\n' "$device_profile"
cd -- "$repo"
bash ./setup-hyprland.sh --profile "$device_profile"
printf '\nDesktop update finished successfully.\nBackup and log: %s\nLog out and back in to load the updated desktop.\n' "$run_dir"
