//@ pragma UseQApplication
// macOS 27 (Golden Gate) Liquid Glass Quickshell entrypoint.
//
// Unified single-window top menu bar + floating Liquid Glass popovers per monitor.
import Quickshell
import QtQuick
import "windows"
import "services"
import "popups"

ShellRoot {
    // Force-instantiate IPC handlers so `qs ipc call ...` always works.
    property var _ipc: Ipc

    Variants {
        model: Quickshell.screens

        delegate: Component {
            Scope {
                required property var modelData

                TopBar       { id: topBar; screen: modelData }
                PopupDismiss { screen: modelData }
                PopupLayer   { barWindow: topBar; screen: modelData }
            }
        }
    }
}
