// Liquid Glass quick tile: frosted glass card with macOS glossy circular toggle orb.
import QtQuick
import "../theme"

Rectangle {
    id: tile

    property string glyph
    property bool spinning: false
    property string title
    property string subtitle
    property bool   active: false
    property bool   toggleable: true
    property color  activeColor: Theme.macBlue

    signal toggled()
    signal opened()

    readonly property bool lit: active || !toggleable

    height: 54
    radius: Theme.ccCardRadius
    color: tileHover.hovered ? Qt.rgba(1, 1, 1, 0.17) : Theme.glassCard
    border.width: 1
    border.color: Theme.glassRim

    Behavior on color { ColorAnimation { duration: Theme.animFast } }

    HoverHandler { id: tileHover; cursorShape: Qt.PointingHandCursor }
    TapHandler { onTapped: tile.opened() }

    Rectangle {
        id: bubble
        anchors { left: parent.left; leftMargin: 10; verticalCenter: parent.verticalCenter }
        width: 34
        height: 34
        radius: 17
        color: tile.lit ? (bubbleHover.hovered ? Qt.lighter(tile.activeColor, 1.12) : tile.activeColor)
             : (bubbleHover.hovered ? Qt.rgba(1, 1, 1, 0.24) : Qt.rgba(1, 1, 1, 0.14))
        border.width: 1
        border.color: tile.lit ? Qt.rgba(1, 1, 1, 0.35) : Qt.rgba(1, 1, 1, 0.18)

        Behavior on color { ColorAnimation { duration: Theme.animFast } }

        // Specular orb highlight
        Rectangle {
            anchors.fill: parent
            radius: parent.radius
            gradient: Gradient {
                GradientStop { position: 0.0; color: Qt.rgba(1, 1, 1, 0.26) }
                GradientStop { position: 0.55; color: "transparent" }
            }
        }

        CenteredIcon {
            anchors.centerIn: parent
            id: tileIcon
            text: tile.glyph
            color: "#ffffff"
            size: 14

            RotationAnimation on rotation {
                running: tile.spinning
                from: 0; to: 360
                duration: 900
                loops: Animation.Infinite
                onRunningChanged: if (!running) tileIcon.rotation = 0
            }
        }

        HoverHandler { id: bubbleHover }
        TapHandler { onTapped: tile.toggleable ? tile.toggled() : tile.opened() }
    }

    Column {
        anchors {
            left: bubble.right
            leftMargin: 10
            right: parent.right
            rightMargin: 10
            verticalCenter: parent.verticalCenter
        }
        spacing: 1

        Text {
            width: parent.width
            text: tile.title
            color: Theme.text
            font.family: Theme.fontFamily
            font.pixelSize: Theme.fontSize
            font.bold: true
            elide: Text.ElideRight
        }
        Text {
            width: parent.width
            visible: text !== ""
            text: tile.subtitle
            color: Theme.subtext0
            font.family: Theme.fontFamily
            font.pixelSize: Theme.fontSizeSmall
            elide: Text.ElideRight
        }
    }
}
