// Reusable macOS 27 Liquid Glass surface container.
// Uses vector Canvas rendering with smooth subpixel anti-aliasing so large
// rounded corners (radius 18-26) have zero polygonal faceting or jagged rims.
import QtQuick
import "../theme"

Item {
    id: root

    property bool  cardStyle: false
    property real  glassRadius: cardStyle ? Theme.ccCardRadius : Theme.ccRadius
    property color tintColor: cardStyle ? Theme.glassCard : Theme.popupBg
    property bool  showSheen: true
    property bool  showTopHighlight: true

    default property alias content: body.data

    Canvas {
        id: glassCanvas
        anchors.fill: parent
        antialiasing: true
        smooth: true

        // Repaint whenever geometry or dynamic Liquid Glass properties change
        onWidthChanged: requestPaint()
        onHeightChanged: requestPaint()

        Connections {
            target: root
            function onGlassRadiusChanged() { glassCanvas.requestPaint() }
            function onTintColorChanged() { glassCanvas.requestPaint() }
            function onCardStyleChanged() { glassCanvas.requestPaint() }
            function onShowSheenChanged() { glassCanvas.requestPaint() }
            function onShowTopHighlightChanged() { glassCanvas.requestPaint() }
        }
        Connections {
            target: Theme
            function onGlassTintChanged() { glassCanvas.requestPaint() }
            function onReduceTransparencyChanged() { glassCanvas.requestPaint() }
            function onGlassRimChanged() { glassCanvas.requestPaint() }
            function onGlassHighlightChanged() { glassCanvas.requestPaint() }
        }

        function roundedPath(ctx, x, y, w, h, r) {
            var rr = Math.max(0, Math.min(r, w / 2, h / 2))
            ctx.beginPath()
            ctx.moveTo(x + rr, y)
            ctx.lineTo(x + w - rr, y)
            ctx.arcTo(x + w, y, x + w, y + rr, rr)
            ctx.lineTo(x + w, y + h - rr)
            ctx.arcTo(x + w, y + h, x + w - rr, y + h, rr)
            ctx.lineTo(x + rr, y + h)
            ctx.arcTo(x, y + h, x, y + h - rr, rr)
            ctx.lineTo(x, y + rr)
            ctx.arcTo(x, y, x + rr, y, rr)
            ctx.closePath()
        }

        onPaint: {
            var ctx = getContext("2d")
            ctx.reset()
            var w = width
            var h = height
            if (w <= 2 || h <= 2) return

            var r = root.glassRadius

            // 1. Base translucent Liquid Glass fill
            roundedPath(ctx, 0.5, 0.5, w - 1, h - 1, r)
            ctx.fillStyle = root.tintColor
            ctx.fill()

            // 2. Vertical refractive glass sheen clipped smoothly to the curve
            if (root.showSheen && !Theme.reduceTransparency) {
                ctx.save()
                roundedPath(ctx, 1, 1, w - 2, h - 2, Math.max(0, r - 0.5))
                ctx.clip()

                var grad = ctx.createLinearGradient(0, 0, 0, h)
                grad.addColorStop(0.0,  root.cardStyle ? "rgba(255,255,255,0.13)" : "rgba(255,255,255,0.18)")
                grad.addColorStop(0.28, "rgba(255,255,255,0.04)")
                grad.addColorStop(0.75, "rgba(255,255,255,0.01)")
                grad.addColorStop(1.0,  "rgba(255,255,255,0.06)")
                ctx.fillStyle = grad
                ctx.fillRect(0, 0, w, h)
                ctx.restore()
            }

            // 3. Smooth subpixel-antialiased specular glass rim (top-lit gradient stroke)
            roundedPath(ctx, 0.75, 0.75, w - 1.5, h - 1.5, r)
            var rimGrad = ctx.createLinearGradient(0, 0, 0, h)
            if (Theme.reduceTransparency) {
                rimGrad.addColorStop(0.0, "rgba(255,255,255,0.18)")
                rimGrad.addColorStop(1.0, "rgba(255,255,255,0.10)")
            } else if (root.cardStyle) {
                rimGrad.addColorStop(0.0, "rgba(255,255,255,0.28)")
                rimGrad.addColorStop(0.45, "rgba(255,255,255,0.14)")
                rimGrad.addColorStop(1.0, "rgba(255,255,255,0.18)")
            } else {
                rimGrad.addColorStop(0.0, "rgba(255,255,255,0.38)")
                rimGrad.addColorStop(0.4, "rgba(255,255,255,0.18)")
                rimGrad.addColorStop(1.0, "rgba(255,255,255,0.24)")
            }
            ctx.strokeStyle = rimGrad
            ctx.lineWidth = 1.0
            ctx.stroke()

            // 4. Subtle top inner catch-light
            if (root.showTopHighlight && !Theme.reduceTransparency) {
                var inset = Math.max(14, r * 0.7)
                if (w > inset * 2 + 4) {
                    var hl = ctx.createLinearGradient(inset, 0, w - inset, 0)
                    hl.addColorStop(0.0, "rgba(255,255,255,0.0)")
                    hl.addColorStop(0.25, "rgba(255,255,255,0.32)")
                    hl.addColorStop(0.75, "rgba(255,255,255,0.32)")
                    hl.addColorStop(1.0, "rgba(255,255,255,0.0)")
                    ctx.beginPath()
                    ctx.moveTo(inset, 1.5)
                    ctx.lineTo(w - inset, 1.5)
                    ctx.strokeStyle = hl
                    ctx.lineWidth = 1.0
                    ctx.stroke()
                }
            }
        }
    }

    Item {
        id: body
        anchors.fill: parent
    }
}
