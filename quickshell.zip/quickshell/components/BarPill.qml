// Reusable macOS 27 Liquid Glass menu bar pill button.
import QtQuick
import "../theme"

Rectangle {
    id: pill

    property bool active: false
    property int  hPad: 8
    default property alias content: inner.data
    signal activated()

    height: 22
    width: inner.implicitWidth + hPad * 2
    radius: 6
    antialiasing: true
    anchors.verticalCenter: parent ? parent.verticalCenter : undefined

    color: active ? Qt.rgba(1, 1, 1, 0.24)
         : hover.hovered ? Qt.rgba(1, 1, 1, 0.15)
         : "transparent"
    border.width: active ? 1 : 0
    border.color: Qt.rgba(1, 1, 1, 0.30)

    Behavior on color { ColorAnimation { duration: Theme.animFast } }

    Row {
        id: inner
        anchors.centerIn: parent
    }

    HoverHandler {
        id: hover
        cursorShape: Qt.PointingHandCursor
    }
    TapHandler {
        onTapped: pill.activated()
    }
}
