// Glossy macOS 27 Liquid Glass slider: sleek frosted glass capsule track with
// luminous white fill, glossy top sheen, and clean embedded left glyph.
import QtQuick
import "../theme"

Item {
    id: root

    property real   value: 0            // 0..1
    property string glyph: ""
    property color  fillColor: "#ffffff"
    property string label: ""

    signal moved(real v)
    signal glyphClicked()

    implicitWidth: 220
    implicitHeight: 26

    property real _local: 0
    readonly property bool _dragging: drag.active
    readonly property real _frac: Math.max(0, Math.min(1, _dragging ? _local : value))

    function _apply(x) {
        var v = Math.max(0, Math.min(1, x / width))
        root._local = v
        root.moved(v)
    }

    Rectangle {
        id: track
        anchors.fill: parent
        radius: height / 2
        color: Qt.rgba(0, 0, 0, 0.22)
        border.width: 1
        border.color: Qt.rgba(1, 1, 1, 0.20)
        antialiasing: true
        layer.enabled: true
        layer.smooth: true
        layer.samples: 4
        clip: true

        // Glossy active capsule fill
        Rectangle {
            id: fill
            width: Math.max(track.height, root._frac * track.width)
            height: parent.height
            radius: parent.radius
            antialiasing: true
            color: root.fillColor

            // Subtle glossy vertical sheen
            Rectangle {
                anchors.fill: parent
                radius: parent.radius
                gradient: Gradient {
                    GradientStop { position: 0.0; color: Qt.rgba(1, 1, 1, 0.35) }
                    GradientStop { position: 0.55; color: "transparent" }
                    GradientStop { position: 1.0; color: Qt.rgba(0, 0, 0, 0.10) }
                }
            }

            Behavior on width {
                enabled: !root._dragging
                NumberAnimation { duration: 110; easing.type: Easing.OutCubic }
            }
            Behavior on color { ColorAnimation { duration: Theme.animFast } }
        }

        // Left glyph cap (clickable e.g. for mute)
        Item {
            id: cap
            width: track.height
            height: track.height

            CenteredIcon {
                anchors.centerIn: parent
                text: root.glyph
                color: "#1c1c1e"
                size: 12
            }

            TapHandler { onTapped: root.glyphClicked() }
        }
    }

    HoverHandler { cursorShape: Qt.PointingHandCursor }

    TapHandler {
        onTapped: function (e) {
            if (e.position.x > cap.width) root._apply(e.position.x)
        }
    }

    DragHandler {
        id: drag
        target: null
        xAxis.enabled: true
        yAxis.enabled: false
        onActiveChanged: if (active) root._local = root.value
        onCentroidChanged: {
            if (drag.active)
                root._apply(drag.centroid.position.x)
        }
    }

    WheelHandler {
        onWheel: function (e) {
            var v = root.value + (e.angleDelta.y > 0 ? 0.05 : -0.05)
            root.moved(Math.max(0, Math.min(1, v)))
        }
    }
}
