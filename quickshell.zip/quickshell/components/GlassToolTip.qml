// macOS 27 Liquid Glass tooltip for tray icons and bar buttons.
import QtQuick
import QtQuick.Controls.Basic
import "../theme"

ToolTip {
    id: root

    delay: 400
    timeout: 4000
    topPadding: 5
    bottomPadding: 5
    leftPadding: 10
    rightPadding: 10
    y: parent ? parent.height + 6 : 28

    enter: Transition {
        NumberAnimation { property: "opacity"; from: 0; to: 1; duration: 130; easing.type: Easing.OutCubic }
    }
    exit: Transition {
        NumberAnimation { property: "opacity"; from: 1; to: 0; duration: 100; easing.type: Easing.InCubic }
    }

    contentItem: Text {
        text: root.text
        color: Theme.text
        font.family: Theme.fontFamily
        font.pixelSize: Theme.fontSizeSmall
        font.weight: Font.Medium
    }

    background: LiquidGlass {
        glassRadius: 10
        tintColor: Qt.rgba(0.11, 0.12, 0.16,
                           Theme.reduceTransparency ? 0.94
                                                    : Math.max(0.76, 0.56 + Theme.glassTint * 0.34))
    }
}
