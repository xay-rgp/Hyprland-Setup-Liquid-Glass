// Authentic macOS Control Center icon (two stacked mini toggle switches).
import QtQuick
import "../theme"

Item {
    id: root

    property color color: Theme.text
    implicitWidth: 16
    implicitHeight: 14

    // Top toggle (knob on left, pill outline)
    Rectangle {
        x: 0
        y: 1
        width: 15
        height: 5.5
        radius: height / 2
        color: "transparent"
        border.width: 1.3
        border.color: root.color

        Rectangle {
            anchors { left: parent.left; leftMargin: 1.5; verticalCenter: parent.verticalCenter }
            width: 3.2
            height: 3.2
            radius: width / 2
            color: root.color
        }
    }

    // Bottom toggle (knob on right, filled pill)
    Rectangle {
        x: 0
        y: 7.8
        width: 15
        height: 5.5
        radius: height / 2
        color: Qt.rgba(root.color.r, root.color.g, root.color.b, 0.28)
        border.width: 1.3
        border.color: root.color

        Rectangle {
            anchors { right: parent.right; rightMargin: 1.5; verticalCenter: parent.verticalCenter }
            width: 3.4
            height: 3.4
            radius: width / 2
            color: root.color
        }
    }
}
