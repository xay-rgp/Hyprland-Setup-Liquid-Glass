// Palette singleton for macOS 27 Liquid Glass theme.
// Dynamically reacts to SettingsService.glassTint, showBarBackground, and
// reduceTransparency so dragging the Liquid Glass slider updates every surface live.
pragma Singleton
import QtQuick
import "."
import "../services"

QtObject {
    id: root

    property ColorLoader _loader: ColorLoader {}

    function reloadTheme() {
        _loader.forceReload()
    }

    // ── Raw palette (kept for compatibility with existing sub-popups) ───────
    property color rosewater: "#f5e0dc"
    property color flamingo:  "#f2cdcd"
    property color pink:      "#ff375f"
    property color mauve:     "#bf5af2"
    property color red:       "#ff453a"
    property color maroon:    "#ff6961"
    property color peach:     "#ff9f0a"
    property color yellow:    "#ffd60a"
    property color green:     "#30d158"
    property color teal:      "#40c8e0"
    property color sky:       "#64d2ff"
    property color sapphire:  "#0a84ff"
    property color blue:      "#0a84ff"
    property color lavender:  "#5e5ce6"

    property color text:      "#ffffff"
    property color subtext1:  "#f2f2f7"
    property color subtext0:  Qt.rgba(1, 1, 1, 0.78)
    property color overlay2:  Qt.rgba(1, 1, 1, 0.58)
    property color overlay1:  Qt.rgba(1, 1, 1, 0.36)
    property color overlay0:  Qt.rgba(1, 1, 1, 0.24)
    property color surface2:  Qt.rgba(1, 1, 1, 0.18)
    property color surface1:  Qt.rgba(1, 1, 1, 0.12)
    property color surface0:  Qt.rgba(1, 1, 1, 0.08)
    property color base:      "#16171a"
    property color mantle:    "#121316"
    property color crust:     "#0a0b0d"

    property string mode:  "dark"
    property bool   loaded: true

    // ── macOS 27 Semantic Accents ───────────────────────────────────────────
    property color accent:     "#0a84ff"
    property color macBlue:    "#0a84ff"
    property color macIndigo:  "#5e5ce6"
    property color macOrange:  "#ff9f0a"
    property color macGreen:   "#30d158"
    property color macRed:     "#ff453a"
    property color urgent:     "#ff453a"
    property color warning:    "#ff9f0a"
    property color success:    "#30d158"

    // ── Liquid Glass Dynamic Properties ─────────────────────────────────────
    readonly property real glassTint: SettingsService.glassTint
    readonly property bool showBarBackground: SettingsService.showBarBackground
    readonly property bool reduceTransparency: SettingsService.reduceTransparency

    // Menu bar surface: ultra-clear by default (macOS 27), smoothly tinted by glassTint
    readonly property real _barAlpha: reduceTransparency ? 0.94
        : showBarBackground ? (0.34 + glassTint * 0.48)
        : (glassTint * 0.42)

    // Floating Liquid Glass panel surface (Control Center, Spotlight, Menus)
    readonly property real _panelAlpha: reduceTransparency ? 0.94
        : (0.40 + glassTint * 0.48)

    // Inner glass card surface inside Control Center
    readonly property real _cardAlpha: reduceTransparency ? 0.22
        : (0.12 + glassTint * 0.10)

    property color barBg:        Qt.rgba(0.11, 0.12, 0.15, _barAlpha)
    property color popupBg:      Qt.rgba(0.11, 0.12, 0.15, _panelAlpha)
    property color popupBgSolid: Qt.rgba(0.11, 0.12, 0.15, Math.max(0.86, _panelAlpha))
    property color glassCard:    Qt.rgba(1, 1, 1, _cardAlpha)
    property color glassRim:     Qt.rgba(1, 1, 1, reduceTransparency ? 0.18 : 0.26)
    property color glassSheenTop:    Qt.rgba(1, 1, 1, reduceTransparency ? 0.04 : 0.18)
    property color glassSheenBottom: Qt.rgba(1, 1, 1, reduceTransparency ? 0.01 : 0.04)
    property color glassHighlight:   Qt.rgba(1, 1, 1, reduceTransparency ? 0.14 : 0.36)
    property color border:       Qt.rgba(1, 1, 1, 0.18)

    // Interaction tints
    property color hover:    Qt.rgba(1, 1, 1, 0.14)
    property color pressed:  Qt.rgba(1, 1, 1, 0.22)
    property color divider:  Qt.rgba(1, 1, 1, 0.12)
    property color inactive: Qt.rgba(1, 1, 1, 0.38)

    // Workspace pills
    property color wsActive:   "#ffffff"
    property color wsOccupied: Qt.rgba(1, 1, 1, 0.55)
    property color wsEmpty:    Qt.rgba(1, 1, 1, 0.22)
    property color wsUrgent:   urgent
}
