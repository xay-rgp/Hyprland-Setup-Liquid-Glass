// Layout constants for the macOS 27 Liquid Glass menu bar and popovers.
pragma Singleton
import QtQuick

QtObject {
    // ── Bar geometry ────────────────────────────────────────────────────────
    property int borderWidth: 0
    property int cornerRadius: 16
    property int cornerRadiusSmall: 10
    property int notchRadius: 12
    property int notchHeight: 30
    property int barHeight: 30
    property int exclusionGap: 30
    property int notchPadding: 10

    property int lNotchMinWidth: 0
    property int lNotchMaxWidth: 500
    property int cNotchMinWidth: 200
    property int cNotchMaxWidth: 400
    property int rNotchMinWidth: 0
    property int rNotchMaxWidth: 600

    // ── Popup sizing ────────────────────────────────────────────────────────
    property int popupPadding: 14
    property int popupWidth: 340
    property int networkPopupWidth: 360
    property int launcherWidth: 580
    property int launcherMaxHeight: 440

    // ── Control center (macOS 27 proportions) ───────────────────────────────
    property int ccWidth: 368
    property int ccHeight: 540
    property int ccPadding: 14
    property int ccRadius: 26
    property int ccCardRadius: 18
    property int ccMorphDuration: 260

    // ── Legacy Island properties (kept for any referencing widgets) ─────────
    property int islandTop: 6
    property int islandRestHeight: 26
    property int islandPeekWidth: 500
    property int islandPeekHeight: 72
    property int islandRadius: 24
    property int islandMorphDuration: 300

    // ── Workspace pills ─────────────────────────────────────────────────────
    property int wsDotSize: 6
    property int wsActiveWidth: 18
    property int wsSpacing: 5
    property int wsPadding: 8
    property int wsRadius: 12

    // ── Animation ───────────────────────────────────────────────────────────
    property int animDuration: 240
    property int animFast: 130
    property int hoverCloseDelay: 220

    // ── Fonts ───────────────────────────────────────────────────────────────
    property string fontFamily: "Adwaita Sans"
    property string iconFont:   "Hack Nerd Font"
    property int fontSize: 13
    property int fontSizeSmall: 11
    property int fontSizeLarge: 14

    // ── Behaviour toggles ───────────────────────────────────────────────────
    property bool barEnabled: true
    property bool focusMode: false
}
