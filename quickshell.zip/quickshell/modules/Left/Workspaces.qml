// Compact macOS-style Spaces / Workspaces pill strip for the Liquid Glass menu bar.
import QtQuick
import Quickshell
import Quickshell.Hyprland
import "../../theme"
import "../../services"

Row {
    id: root

    required property var screen

    spacing: 4
    height: 22

    readonly property var _live: HyprlandService.workspacesFor(root.screen)

    readonly property var _ids: {
        var out = []
        for (var j = 0; j < _live.length; j++)
            out.push(_live[j].id)
        if (out.length === 0)
            out.push(1)
        out.sort(function (a, b) { return a - b })
        return out
    }

    function _wsFor(id) {
        for (var i = 0; i < _live.length; i++)
            if (_live[i].id === id)
                return _live[i]
        return null
    }

    function _go(id) {
        if (Hyprland.usingLua)
            Hyprland.dispatch('hl.dsp.focus({ workspace = "' + id + '" })')
        else
            Hyprland.dispatch("workspace " + id)
    }

    Repeater {
        model: root._ids

        delegate: Rectangle {
            id: pill
            required property var modelData

            readonly property var ws: root._wsFor(modelData)
            readonly property bool isActive:   ws ? ws.active : false
            readonly property bool isUrgent:   ws ? ws.urgent : false
            readonly property bool isOccupied: ws ? ws.toplevels.values.length > 0 : false

            width: isActive ? 22 : 18
            height: 18
            radius: 9
            antialiasing: true
            layer.enabled: true
            layer.smooth: true
            layer.samples: 4
            anchors.verticalCenter: parent.verticalCenter

            color: isUrgent ? Theme.macRed
                 : isActive ? Qt.rgba(1, 1, 1, 0.28)
                 : hover.hovered ? Qt.rgba(1, 1, 1, 0.16)
                 : "transparent"
            border.width: isActive ? 1 : 0
            border.color: Qt.rgba(1, 1, 1, 0.40)

            Behavior on width { NumberAnimation { duration: Theme.animFast; easing.type: Easing.OutCubic } }
            Behavior on color { ColorAnimation { duration: Theme.animFast } }

            Text {
                anchors.centerIn: parent
                text: String(pill.modelData)
                color: pill.isActive ? "#ffffff"
                     : pill.isOccupied ? Qt.rgba(1, 1, 1, 0.82)
                     : Qt.rgba(1, 1, 1, 0.45)
                font.family: Theme.fontFamily
                font.pixelSize: 10
                font.bold: pill.isActive
            }

            HoverHandler {
                id: hover
                cursorShape: Qt.PointingHandCursor
            }
            TapHandler {
                onTapped: root._go(pill.modelData)
            }
        }
    }

    WheelHandler {
        onWheel: function (event) {
            var ids = root._ids
            if (ids.length <= 1) return
            var cur = 0
            for (var i = 0; i < ids.length; i++) {
                var w = root._wsFor(ids[i])
                if (w && w.active) { cur = i; break }
            }
            var step = event.angleDelta.y > 0 ? -1 : 1
            root._go(ids[(cur + step + ids.length) % ids.length])
        }
    }
}
