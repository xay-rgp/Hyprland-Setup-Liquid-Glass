// macOS 27 Liquid Glass menu item for SystemTray context menus (e.g. Steam).
import QtQuick
import QtQuick.Controls.Basic
import "../../theme"

MenuItem {
    id: root
    implicitWidth: 236
    implicitHeight: 28
    leftPadding: 30
    rightPadding: 24
    font.family: Theme.fontFamily
    font.pixelSize: Theme.fontSize

    background: Rectangle {
        radius: 8
        antialiasing: true
        color: root.highlighted ? Theme.macBlue : "transparent"
        border.width: root.highlighted ? 1 : 0
        border.color: Qt.rgba(1, 1, 1, 0.28)

        Behavior on color {
            ColorAnimation { duration: 90; easing.type: Easing.OutCubic }
        }
    }

    contentItem: Text {
        text: root.text.replace(/&&/g, "\u0000").replace(/&/g, "").replace(/\u0000/g, "&")
        textFormat: Text.PlainText
        font: root.font
        color: root.highlighted ? "#ffffff"
             : root.enabled ? Theme.text
             : Theme.inactive
        verticalAlignment: Text.AlignVCenter
        elide: Text.ElideRight
    }

    indicator: Text {
        x: 9
        anchors.verticalCenter: parent.verticalCenter
        text: root.checked ? "✓" : ""
        color: root.highlighted ? "#ffffff"
             : root.enabled ? Theme.text
             : Theme.inactive
        font: root.font
    }

    Image {
        x: 8
        anchors.verticalCenter: parent.verticalCenter
        width: 15
        height: 15
        source: root.icon.source
        sourceSize: Qt.size(30, 30)
        visible: !root.checkable && source.toString() !== ""
        opacity: root.enabled ? 1 : 0.35
    }

    arrow: Text {
        x: root.width - width - 9
        anchors.verticalCenter: parent.verticalCenter
        text: "›"
        visible: root.subMenu !== null
        color: root.highlighted ? "#ffffff"
             : root.enabled ? Theme.subtext1
             : Theme.inactive
        font.pixelSize: 16
    }
}
